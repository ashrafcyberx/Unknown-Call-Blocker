package com.ashrafcyberx.unknowncallblocker

import android.content.Intent
import android.content.res.ColorStateList
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.ashrafcyberx.unknowncallblocker.databinding.FragmentSettingsBinding

class SettingsFragment : Fragment() {
    private var _b: FragmentSettingsBinding? = null
    private val b get() = _b!!
    private var updating = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _b = FragmentSettingsBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val ctx = requireContext()
        val settings = AppSettings(ctx)

        b.btnBack.setOnClickListener { (requireActivity() as MainActivity).select(R.id.nav_home) }
        b.rowBlock.setOnClickListener { b.switchBlocking.toggle() }
        b.rowPrivate.setOnClickListener { b.switchHidden.toggle() }
        b.switchBlocking.setOnCheckedChangeListener { _, checked ->
            if (!updating) settings.blockingEnabled = checked
        }
        b.switchHidden.setOnCheckedChangeListener { _, checked ->
            if (!updating) {
                settings.hiddenCallerPolicy = if (checked) HiddenCallerPolicy.BLOCK else HiddenCallerPolicy.ALLOW
            }
        }
        b.rowBlocked.setOnClickListener { open(BlockedNumbersActivity::class.java) }
        b.rowLogs.setOnClickListener { (requireActivity() as MainActivity).select(R.id.nav_logs) }
        b.rowContacts.setOnClickListener { open(PermissionsActivity::class.java) }
        b.rowRole.setOnClickListener { open(PermissionsActivity::class.java) }
        b.rowHow.setOnClickListener { open(HowItWorksActivity::class.java) }
        b.textVersion.text = ctx.appVersion()
    }

    override fun onResume() {
        super.onResume()
        val binding = _b ?: return
        val ctx = requireContext()
        val settings = AppSettings(ctx)
        updating = true
        binding.switchBlocking.isChecked = settings.blockingEnabled
        binding.switchHidden.isChecked = settings.hiddenCallerPolicy == HiddenCallerPolicy.BLOCK
        updating = false
        showStatus(binding.textContactsStatus, Setup.hasContacts(ctx), "Granted")
        showStatus(binding.textRoleStatus, Setup.hasRole(ctx), "Selected")
    }

    private fun showStatus(view: TextView, ok: Boolean, okText: String) {
        val color = requireContext().getColor(if (ok) R.color.accent else R.color.warning)
        view.text = if (ok) okText else "Not set"
        view.setTextColor(color)
        view.compoundDrawableTintList = ColorStateList.valueOf(color)
    }

    private fun open(target: Class<*>) = startActivity(Intent(requireContext(), target))

    override fun onDestroyView() {
        super.onDestroyView()
        _b = null
    }
}
