package com.ashrafcyberx.unknowncallblocker

import android.content.Intent
import android.content.res.ColorStateList
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.PopupMenu
import androidx.fragment.app.Fragment
import com.ashrafcyberx.unknowncallblocker.databinding.FragmentHomeBinding

class HomeFragment : Fragment() {
    private var _b: FragmentHomeBinding? = null
    private val b get() = _b!!
    private var updating = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _b = FragmentHomeBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val ctx = requireContext()
        val settings = AppSettings(ctx)
        val main = requireActivity() as MainActivity

        b.btnMenu.setOnClickListener { showMenu(it) }
        b.btnSettings.setOnClickListener { main.select(R.id.nav_settings) }
        b.cardSaved.setOnClickListener { main.select(R.id.nav_contacts) }
        b.cardLogs.setOnClickListener { main.select(R.id.nav_logs) }
        b.ringContainer.setOnClickListener {
            if (!Setup.isComplete(ctx)) startActivity(Intent(ctx, PermissionsActivity::class.java))
        }
        b.switchBlocking.setOnCheckedChangeListener { _, checked ->
            if (updating) return@setOnCheckedChangeListener
            settings.blockingEnabled = checked
            refresh()
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun showMenu(anchor: View) {
        val ctx = requireContext()
        val popup = PopupMenu(ctx, anchor)
        popup.menu.add(0, 1, 0, "Blocked Numbers")
        popup.menu.add(0, 2, 1, "Permissions")
        popup.menu.add(0, 3, 2, "How It Works")
        popup.setOnMenuItemClickListener { item ->
            val target = when (item.itemId) {
                1 -> BlockedNumbersActivity::class.java
                2 -> PermissionsActivity::class.java
                else -> HowItWorksActivity::class.java
            }
            startActivity(Intent(ctx, target))
            true
        }
        popup.show()
    }

    private fun refresh() {
        val binding = _b ?: return
        val ctx = requireContext()
        val settings = AppSettings(ctx)

        updating = true
        binding.switchBlocking.isChecked = settings.blockingEnabled
        updating = false

        val title: String
        val sub: String
        val color: Int
        when {
            !Setup.isComplete(ctx) -> {
                title = "Setup Required"; sub = "Tap to finish setup"; color = R.color.warning
            }
            !settings.blockingEnabled -> {
                title = "Blocking Off"; sub = "All calls are allowed"; color = R.color.text_secondary
            }
            else -> {
                title = "Blocking Active"; sub = "Unknown numbers will be rejected"; color = R.color.accent
            }
        }
        val tint = ColorStateList.valueOf(ctx.getColor(color))
        binding.ringTitle.text = title
        binding.ringSub.text = sub
        binding.ringContainer.backgroundTintList = tint
        binding.icShield.imageTintList = tint

        val (total, blocked) = CallLogStore(ctx).todayCounts()
        binding.textTotal.text = total.toString()
        binding.textBlockedToday.text = blocked.toString()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _b = null
    }
}
