package com.ashrafcyberx.unknowncallblocker

import android.content.Intent
import android.content.res.ColorStateList
import android.os.Bundle
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.PopupMenu
import androidx.fragment.app.Fragment
import com.ashrafcyberx.unknowncallblocker.databinding.FragmentHomeBinding

class HomeFragment : Fragment() {
    private var _b: FragmentHomeBinding? = null
    private val b get() = _b!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _b = FragmentHomeBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val main = requireActivity() as MainActivity

        b.btnMenu.setOnClickListener { showMenu(it) }
        b.btnSettings.setOnClickListener { main.select(R.id.nav_settings) }
        b.cardSaved.setOnClickListener { main.select(R.id.nav_contacts) }
        b.cardLogs.setOnClickListener { main.select(R.id.nav_logs) }
        b.toggleTrack.setOnClickListener { toggle(it) }
        b.powerButton.setOnClickListener { toggle(it) }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun toggle(from: View) {
        val ctx = requireContext()
        if (!Setup.isComplete(ctx)) {
            startActivity(Intent(ctx, PermissionsActivity::class.java))
            return
        }
        from.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        val settings = AppSettings(ctx)
        settings.blockingEnabled = !settings.blockingEnabled
        refresh()
        b.powerButton.scaleX = 0.88f
        b.powerButton.scaleY = 0.88f
        b.powerButton.animate().scaleX(1f).scaleY(1f).setDuration(220).start()
    }

    private fun showMenu(anchor: View) {
        val ctx = requireContext()
        val popup = PopupMenu(ctx, anchor)
        popup.menu.add(0, 1, 0, "Blocked Numbers")
        popup.menu.add(0, 2, 1, "Permissions")
        popup.menu.add(0, 3, 2, "How It Works")
        popup.setOnMenuItemClickListener { item ->
            val target = when (item.itemId) {
                1 -> BlockedNumbersActivity::class.java
                2 -> PermissionsActivity::class.java
                else -> HowItWorksActivity::class.java
            }
            startActivity(Intent(ctx, target))
            true
        }
        popup.show()
    }

    private fun refresh() {
        val binding = _b ?: return
        val ctx = requireContext()
        val settings = AppSettings(ctx)

        val color: Int
        val title: String
        val desc: String
        val label: String
        val powerBg: Int
        when {
            !Setup.isComplete(ctx) -> {
                color = R.color.warning; title = "Setup"; label = "SETUP"
                desc = "Tap to finish setup and start blocking."
                powerBg = R.drawable.bg_power_off
            }
            !settings.blockingEnabled -> {
                color = R.color.toggle_off; title = "Disabled"; label = "OFF"
                desc = "Unknown numbers are allowed to call you."
                powerBg = R.drawable.bg_power_off
            }
            else -> {
                color = R.color.toggle_on; title = "Active"; label = "ON"
                desc = "Unknown numbers will be rejected automatically."
                powerBg = R.drawable.bg_power_on
            }
        }
        val c = ctx.getColor(color)
        val tint = ColorStateList.valueOf(c)

        binding.trackStroke.backgroundTintList = tint
        binding.trackDivider.backgroundTintList = tint
        binding.icShield.imageTintList = tint
        binding.powerButton.setBackgroundResource(powerBg)
        binding.powerButton.backgroundTintList = tint
        binding.textState.text = title
        binding.textState.setTextColor(c)
        binding.textStateDesc.text = desc
        binding.textPower.text = label

        val (total, blocked) = CallLogStore(ctx).todayCounts()
        binding.textTotal.text = total.toString()
        binding.textBlockedToday.text = blocked.toString()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _b = null
    }
}
