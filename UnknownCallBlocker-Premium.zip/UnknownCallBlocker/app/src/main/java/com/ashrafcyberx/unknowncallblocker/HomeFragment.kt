package com.ashrafcyberx.unknowncallblocker

import android.animation.ArgbEvaluator
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Intent
import android.content.res.ColorStateList
import android.os.Bundle
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.PopupMenu
import androidx.fragment.app.Fragment
import com.ashrafcyberx.unknowncallblocker.databinding.FragmentHomeBinding
import com.google.android.material.snackbar.Snackbar

class HomeFragment : Fragment() {
    private var _b: FragmentHomeBinding? = null
    private val b get() = _b!!

    private var shownColor: Int? = null
    private var shownTitle: String? = null
    private var colorAnim: ValueAnimator? = null
    private var pulse: ObjectAnimator? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _b = FragmentHomeBinding.inflate(inflater, container, false)
        return b.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val main = requireActivity() as MainActivity

        b.btnMenu.setOnClickListener { showMenu(it) }
        b.btnSettings.setOnClickListener { main.select(R.id.nav_settings) }
        b.cardSaved.setOnClickListener { main.select(R.id.nav_contacts) }
        b.cardLogs.setOnClickListener { main.select(R.id.nav_logs) }
        b.toggleTrack.setOnClickListener { toggle(it) }
        b.powerButton.setOnClickListener { toggle(it) }

        // Soft press feedback on the whole pill (click still goes through).
        b.toggleTrack.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.98f).scaleY(0.98f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(180).setInterpolator(OvershootInterpolator()).start()
            }
            false
        }

        playEntrance()
    }

    /** One staggered slide-up when the app first opens. Not repeated on tab switches. */
    private fun playEntrance() {
        if (entranceShown || !ValueAnimator.areAnimatorsEnabled()) { entranceShown = true; return }
        entranceShown = true
        val content = b.root.getChildAt(0) as ViewGroup
        val dy = 24 * resources.displayMetrics.density
        for (i in 1 until content.childCount) {
            val v = content.getChildAt(i)
            v.alpha = 0f
            v.translationY = dy
            v.animate().alpha(1f).translationY(0f)
                .setStartDelay(70L * i).setDuration(400)
                .setInterpolator(DecelerateInterpolator()).start()
        }
    }

    override fun onResume() {
        super.onResume()
        refresh(animate = false)
    }

    override fun onPause() {
        super.onPause()
        stopPulse()
    }

    private fun toggle(from: View) {
        val ctx = requireContext()
        if (!Setup.isComplete(ctx)) {
            startActivity(Intent(ctx, PermissionsActivity::class.java))
            return
        }
        from.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        val settings = AppSettings(ctx)
        settings.blockingEnabled = !settings.blockingEnabled
        refresh(animate = true)

        // Power button: bounce + icon spin
        b.powerButton.scaleX = 0.82f
        b.powerButton.scaleY = 0.82f
        b.powerButton.animate().scaleX(1f).scaleY(1f).setDuration(420)
            .setInterpolator(OvershootInterpolator(2.2f)).start()
        b.icPower.animate().rotationBy(360f).setDuration(480)
            .setInterpolator(DecelerateInterpolator()).start()

        val msg = if (settings.blockingEnabled) "Call blocking turned on" else "Call blocking turned off"
        Snackbar.make(b.root, msg, Snackbar.LENGTH_SHORT)
            .setAnchorView(requireActivity().findViewById<View>(R.id.bottomNav))
            .setBackgroundTint(ctx.getColor(R.color.surface_alt))
            .setTextColor(ctx.getColor(R.color.text_primary))
            .show()
    }

    private fun showMenu(anchor: View) {
        val ctx = requireContext()
        val popup = PopupMenu(ctx, anchor)
        popup.menu.add(0, 1, 0, "Blocked Numbers")
        popup.menu.add(0, 2, 1, "Permissions")
        popup.menu.add(0, 3, 2, "How It Works")
        popup.setOnMenuItemClickListener { item ->
            val target = when (item.itemId) {
                1 -> BlockedNumbersActivity::class.java
                2 -> PermissionsActivity::class.java
                else -> HowItWorksActivity::class.java
            }
            startActivity(Intent(ctx, target))
            true
        }
        popup.show()
    }

    private fun applyColor(c: Int) {
        val binding = _b ?: return
        val tint = ColorStateList.valueOf(c)
        binding.trackStroke.backgroundTintList = tint
        binding.trackDivider.backgroundTintList = tint
        binding.icShield.imageTintList = tint
        binding.powerButton.backgroundTintList = tint
        binding.textState.setTextColor(c)
        shownColor = c
    }

    private fun startPulse() {
        stopPulse()
        if (!ValueAnimator.areAnimatorsEnabled()) return
        pulse = ObjectAnimator.ofFloat(b.trackStroke, View.ALPHA, 1f, 0.65f).apply {
            duration = 1700
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
    }

    private fun stopPulse() {
        pulse?.cancel()
        pulse = null
        _b?.trackStroke?.alpha = 1f
    }

    private fun refresh(animate: Boolean) {
        val binding = _b ?: return
        val ctx = requireContext()
        val settings = AppSettings(ctx)

        val color: Int
        val title: String
        val desc: String
        val label: String
        val powerBg: Int
        val active: Boolean
        when {
            !Setup.isComplete(ctx) -> {
                color = R.color.warning; title = "Setup"; label = "SETUP"
                desc = "Tap to finish setup and start blocking."
                powerBg = R.drawable.bg_power_off; active = false
            }
            !settings.blockingEnabled -> {
                color = R.color.toggle_off; title = "Disabled"; label = "OFF"
                desc = "Unknown numbers are allowed to call you."
                powerBg = R.drawable.bg_power_off; active = false
            }
            else -> {
                color = R.color.toggle_on; title = "Active"; label = "ON"
                desc = "Unknown numbers will be rejected automatically."
                powerBg = R.drawable.bg_power_on; active = true
            }
        }
        val target = ctx.getColor(color)

        binding.powerButton.setBackgroundResource(powerBg)
        binding.textPower.text = label
        binding.textStateDesc.text = desc

        // Colour cross-fade between states
        colorAnim?.cancel()
        val from = shownColor
        if (animate && from != null && from != target) {
            colorAnim = ValueAnimator.ofObject(ArgbEvaluator(), from, target).apply {
                duration = 380
                addUpdateListener { applyColor(it.animatedValue as Int) }
                start()
            }
        } else {
            applyColor(target)
        }

        // Title fades in when the state changes
        if (animate && shownTitle != null && shownTitle != title) {
            binding.textState.alpha = 0f
            binding.textState.animate().alpha(1f).setDuration(280).start()
            binding.textStateDesc.alpha = 0f
            binding.textStateDesc.animate().alpha(1f).setDuration(280).start()
        }
        binding.textState.text = title
        shownTitle = title

        if (active) startPulse() else stopPulse()

        val (total, blocked) = CallLogStore(ctx).todayCounts()
        binding.textTotal.text = total.toString()
        binding.textBlockedToday.text = blocked.toString()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        colorAnim?.cancel()
        stopPulse()
        shownColor = null
        shownTitle = null
        _b = null
    }

    private companion object {
        var entranceShown = false
    }
}
