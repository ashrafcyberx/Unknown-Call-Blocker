package com.ashrafcyberx.unknowncallblocker

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.widget.doOnTextChanged
import androidx.fragment.app.Fragment
import com.ashrafcyberx.unknowncallblocker.databinding.DialogContactEditorBinding
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog

/**
 * Bottom sheet to save a new contact, or change photo + name style of an existing one.
 * [existing] == null -> new contact. Photo picking is delegated to the fragment (see [onPhotoPicked]).
 */
class ContactEditorDialog(
    private val fragment: Fragment,
    private val existing: ContactItem?,
    private val requestPhoto: () -> Unit,
    private val onSaved: () -> Unit
) {
    private val ctx = fragment.requireContext()
    private val b = DialogContactEditorBinding.inflate(LayoutInflater.from(ctx))
    private val dialog = BottomSheetDialog(ctx)
    private val styles = ContactStyleStore(ctx)

    private var style: NameStyle = existing?.let { styles.get(it.id) } ?: NameStyle()
    private var photoJpeg: ByteArray? = null
    private var saving = false

    fun show() {
        dialog.setContentView(b.root)
        (b.root.parent as? View)?.setBackgroundColor(Color.TRANSPARENT)
        val r = ctx.dpf(26f)
        b.root.background = GradientDrawable().apply {
            setColor(ctx.getColor(R.color.surface_alt))
            cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        }
        dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        dialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        dialog.behavior.skipCollapsed = true

        val fieldBg = { GlassUi.tinted(ctx, Color.WHITE, 14f, fill = 0.06f, line = 0.12f) }
        b.editName.background = fieldBg()
        b.editNumber.background = fieldBg()
        b.preview.background = GlassUi.tinted(ctx, Color.WHITE, 16f, fill = 0.04f, line = 0.10f)

        val accent = ctx.getColor(R.color.accent)
        b.photoInitial.background = GlassUi.tinted(ctx, accent, 0f, oval = true, fill = 0.15f, line = 0.30f)
        b.photoInitial.setTextColor(accent)
        b.photo.clipToOutline = true
        b.photo.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setOval(0, 0, view.width, view.height)
            }
        }
        b.photoInitial.setOnClickListener { requestPhoto() }
        b.photo.setOnClickListener { requestPhoto() }
        b.btnPhoto.setOnClickListener { requestPhoto() }

        if (existing == null) {
            b.textTitle.text = "New contact"
        } else {
            b.textTitle.text = "Photo & name style"
            b.editName.setText(existing.name)
            b.editNumber.setText(existing.number)
            b.editName.isEnabled = false
            b.editNumber.isEnabled = false
            b.editName.alpha = 0.6f
            b.editNumber.alpha = 0.6f
            existing.photoUri?.let { uri ->
                PhotoLoader.load(b.photo, uri) { ok ->
                    if (ok) {
                        b.photo.visibility = View.VISIBLE
                        b.btnPhoto.text = "Change photo"
                    }
                }
            }
        }

        b.editName.doOnTextChanged { _, _, _, _ -> refreshPreview() }
        buildStyleRows()
        refreshPreview()
        b.btnSave.setOnClickListener { save() }
        dialog.show()
    }

    /** Called by the fragment with the image the user picked. */
    fun onPhotoPicked(uri: Uri) {
        Thread {
            val prepared: Pair<ByteArray, Bitmap>? = try {
                PhotoPrep.toJpeg(ctx, uri)
            } catch (e: Exception) {
                null
            }
            b.root.post {
                if (prepared == null) {
                    Toast.makeText(ctx, "Couldn't read that image.", Toast.LENGTH_SHORT).show()
                } else {
                    photoJpeg = prepared.first
                    b.photo.tag = null
                    b.photo.setImageBitmap(prepared.second)
                    b.photo.visibility = View.VISIBLE
                    b.btnPhoto.text = "Change photo"
                }
            }
        }.start()
    }

    private fun currentName(): String =
        b.editName.text?.toString()?.trim().orEmpty().ifEmpty { "Contact name" }

    private fun refreshPreview() {
        NameStyles.apply(b.preview, currentName(), style)
        val initial = currentName().firstOrNull { it.isLetterOrDigit() }?.uppercase()
        if (existing == null && b.editName.text.isNullOrBlank()) b.photoInitial.text = "+"
        else b.photoInitial.text = initial ?: "#"
    }

    private fun buildStyleRows() {
        b.rowFont.removeAllViews()
        NameStyles.FONT_NAMES.forEachIndexed { i, label ->
            b.rowFont.addView(chip(label, style.font == i) { style = style.copy(font = i); buildStyleRows(); refreshPreview() })
        }
        b.rowLetters.removeAllViews()
        NameStyles.LETTER_NAMES.forEachIndexed { i, label ->
            b.rowLetters.addView(chip(label, style.letters == i) { style = style.copy(letters = i); buildStyleRows(); refreshPreview() })
        }
        b.rowColor.removeAllViews()
        NameStyles.COLORS.forEachIndexed { i, color ->
            val dot = View(ctx)
            val size = ctx.dpf(34f).toInt()
            dot.layoutParams = LinearLayout.LayoutParams(size, size).apply { marginEnd = ctx.dpf(10f).toInt() }
            dot.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(color)
                if (style.color == i) setStroke(ctx.dpf(3f).toInt(), Color.WHITE)
                else setStroke(ctx.dpf(1f).toInt(), GlassUi.withAlpha(Color.WHITE, 0.25f))
            }
            dot.contentDescription = "Colour ${i + 1}"
            dot.setOnClickListener { style = style.copy(color = i); buildStyleRows(); refreshPreview() }
            b.rowColor.addView(dot)
        }
    }

    private fun chip(label: String, selected: Boolean, onClick: () -> Unit): TextView {
        val accent = ctx.getColor(R.color.accent)
        return TextView(ctx).apply {
            text = label
            textSize = 13.5f
            setPadding(ctx.dpf(14f).toInt(), ctx.dpf(8f).toInt(), ctx.dpf(14f).toInt(), ctx.dpf(8f).toInt())
            setTextColor(if (selected) accent else ctx.getColor(R.color.text_soft))
            background = if (selected) GlassUi.tinted(ctx, accent, 20f, fill = 0.16f, line = 0.45f)
            else GlassUi.tinted(ctx, Color.WHITE, 20f, fill = 0.05f, line = 0.12f)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { marginEnd = ctx.dpf(8f).toInt() }
            setOnClickListener { onClick() }
        }
    }

    private fun save() {
        if (saving) return
        val name = b.editName.text?.toString()?.trim().orEmpty()
        val number = b.editNumber.text?.toString()?.trim().orEmpty()
        if (existing == null) {
            if (name.isEmpty()) {
                b.editName.error = "Enter a name"
                return
            }
            if (PhoneNumberMatcher.digitsOnly(number).length < 3) {
                b.editNumber.error = "Enter a valid number"
                return
            }
        }
        saving = true
        b.btnSave.isEnabled = false
        val photo = photoJpeg
        Thread {
            val writer = ContactWriter(ctx)
            val outcome = runCatching {
                if (existing == null) {
                    writer.createContact(name, number, photo)
                } else {
                    if (photo != null) writer.setPhoto(existing.id, photo)
                    existing.id
                }
            }
            b.root.post {
                saving = false
                b.btnSave.isEnabled = true
                outcome.onSuccess { id ->
                    styles.set(id, style)
                    PhotoLoader.clear()
                    dialog.dismiss()
                    Toast.makeText(ctx, if (existing == null) "Contact saved" else "Saved", Toast.LENGTH_SHORT).show()
                    onSaved()
                }.onFailure { e ->
                    Toast.makeText(ctx, e.message ?: "Couldn't save the contact.", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }
}
