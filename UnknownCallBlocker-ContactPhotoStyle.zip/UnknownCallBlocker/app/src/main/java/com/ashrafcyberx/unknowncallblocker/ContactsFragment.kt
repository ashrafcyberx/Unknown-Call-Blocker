package com.ashrafcyberx.unknowncallblocker

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.ContentUris
import android.content.Intent
import android.graphics.Color
import android.graphics.Outline
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.PopupMenu
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.widget.doOnTextChanged
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ashrafcyberx.unknowncallblocker.databinding.FragmentContactsBinding
import com.ashrafcyberx.unknowncallblocker.databinding.ItemContactBinding

class ContactsFragment : Fragment() {
    private var _b: FragmentContactsBinding? = null
    private val b get() = _b!!

    private var all: List<ContactItem> = emptyList()
    private var filter = 0 // 0 = all, 1 = favorites, 2 = groups
    private var query = ""

    private var styleStore: ContactStyleStore? = null
    private var editor: ContactEditorDialog? = null
    private var pendingEdit: ContactItem? = null

    private val adapter = ContactsAdapter(
        onCall = { item -> dial(item.number) },
        onMore = { view, item -> showMore(view, item) },
        styleOf = { id -> styleStore?.get(id) ?: NameStyle() }
    )

    private val writePermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (hasWriteAccess()) openEditor(pendingEdit)
            else Toast.makeText(requireContext(), "Contacts permission is needed to save contacts.", Toast.LENGTH_LONG).show()
            load()
        }

    private val pickImage =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) editor?.onPhotoPicked(uri)
        }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { load() }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _b = FragmentContactsBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        b.list.layoutManager = LinearLayoutManager(requireContext())
        b.list.adapter = adapter
        styleStore = ContactStyleStore(requireContext())
        b.btnAddContact.setOnClickListener { startEditor(null) }
        b.btnGrant.setOnClickListener { permissionLauncher.launch(Manifest.permission.READ_CONTACTS) }
        b.editSearch.doOnTextChanged { text, _, _, _ ->
            query = text?.toString().orEmpty()
            applyFilter()
        }
        b.chipAll.setOnClickListener { setFilter(0) }
        b.chipFav.setOnClickListener { setFilter(1) }
        b.chipGroups.setOnClickListener { setFilter(2) }
        setFilter(0)
    }

    override fun onResume() {
        super.onResume()
        PhotoLoader.clear()
        load()
    }

    private fun setFilter(value: Int) {
        filter = value
        b.chipAll.isSelected = value == 0
        b.chipFav.isSelected = value == 1
        b.chipGroups.isSelected = value == 2
        applyFilter()
    }

    private fun load() {
        val binding = _b ?: return
        if (!Setup.hasContacts(requireContext())) {
            all = emptyList()
            applyFilter()
            return
        }
        val repo = ContactsRepository(requireContext())
        Thread {
            val list = try {
                repo.listContacts()
            } catch (e: Exception) {
                emptyList()
            }
            binding.root.post {
                if (_b != null) {
                    all = list
                    applyFilter()
                }
            }
        }.start()
    }

    private fun applyFilter() {
        val binding = _b ?: return
        val permitted = Setup.hasContacts(requireContext())
        val q = query.trim()
        val shown = all.filter { item ->
            val byFilter = when (filter) {
                1 -> item.starred
                2 -> item.inGroup
                else -> true
            }
            val byQuery = q.isEmpty() ||
                item.name.contains(q, ignoreCase = true) ||
                PhoneNumberMatcher.digitsOnly(item.number).contains(PhoneNumberMatcher.digitsOnly(q).ifEmpty { "\u0000" })
            byFilter && byQuery
        }
        adapter.submit(shown)

        binding.btnGrant.visibility = if (permitted) View.GONE else View.VISIBLE
        binding.emptyBox.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
        binding.textEmpty.text = if (!permitted) {
            "Contacts access is needed to show your saved contacts."
        } else {
            "No contacts found."
        }
    }

    private fun hasWriteAccess(): Boolean =
        Setup.hasContacts(requireContext()) &&
            androidx.core.content.ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.WRITE_CONTACTS) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED

    /** Opens the editor (asks for contacts write permission first if needed). */
    private fun startEditor(item: ContactItem?) {
        if (hasWriteAccess()) {
            openEditor(item)
        } else {
            pendingEdit = item
            writePermissionLauncher.launch(arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS))
        }
    }

    private fun openEditor(item: ContactItem?) {
        if (_b == null) return
        editor = ContactEditorDialog(
            fragment = this,
            existing = item,
            requestPhoto = { pickImage.launch("image/*") },
            onSaved = { load() }
        ).also { it.show() }
    }

    private fun dial(number: String) {
        try {
            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(requireContext(), "No dialer app found.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showMore(anchor: View, item: ContactItem) {
        val popup = PopupMenu(requireContext(), anchor)
        popup.menu.add(0, 2, 0, "Photo & name style")
        popup.menu.add(0, 1, 1, "Open in Contacts")
        popup.setOnMenuItemClickListener { menuItem ->
            if (menuItem.itemId == 2) {
                startEditor(item)
                return@setOnMenuItemClickListener true
            }
            try {
                startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, item.id)
                    )
                )
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(requireContext(), "No contacts app found.", Toast.LENGTH_SHORT).show()
            }
            true
        }
        popup.show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _b = null
    }
}

class ContactsAdapter(
    private val onCall: (ContactItem) -> Unit,
    private val onMore: (View, ContactItem) -> Unit,
    private val styleOf: (Long) -> NameStyle
) : RecyclerView.Adapter<ContactsAdapter.VH>() {

    private var items: List<ContactItem> = emptyList()

    fun submit(list: List<ContactItem>) {
        items = list
        notifyDataSetChanged()
    }

    class VH(val b: ItemContactBinding) : RecyclerView.ViewHolder(b.root) {
        init {
            b.photo.clipToOutline = true
            b.photo.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setOval(0, 0, view.width, view.height)
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemContactBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        NameStyles.apply(holder.b.textName, item.name, styleOf(item.id))
        holder.b.textNumber.text = item.number
        holder.b.avatar.text = item.name.firstOrNull { it.isLetterOrDigit() }?.uppercase() ?: "#"
        val ctx = holder.itemView.context
        val color = PALETTE[Math.abs(item.name.hashCode()) % PALETTE.size]
        holder.b.avatar.background = GlassUi.tinted(ctx, color, 0f, oval = true, fill = 0.15f, line = 0.30f)
        holder.b.avatar.setTextColor(color)
        holder.b.photo.visibility = View.GONE
        holder.b.photo.tag = null
        holder.b.photo.setImageDrawable(null)
        holder.b.avatar.visibility = View.VISIBLE
        item.photoUri?.let { uri ->
            PhotoLoader.load(holder.b.photo, uri) { ok ->
                if (ok) {
                    holder.b.photo.visibility = View.VISIBLE
                    holder.b.avatar.visibility = View.INVISIBLE
                }
            }
        }
        holder.b.divider.visibility = if (position == 0) View.GONE else View.VISIBLE
        holder.b.btnCall.setOnClickListener { onCall(item) }
        holder.b.btnMore.setOnClickListener { onMore(it, item) }
    }

    private companion object {
        val PALETTE = intArrayOf(
            Color.parseColor("#55F5A5"), Color.parseColor("#50F4FF"), Color.parseColor("#9D8CFF"),
            Color.parseColor("#FFB340"), Color.parseColor("#FF6B62"), Color.parseColor("#4F8CFF")
        )
    }
}
