package com.ashrafcyberx.unknowncallblocker

import android.content.ContentProviderOperation
import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.ContactsContract.CommonDataKinds.StructuredName
import android.util.LruCache
import android.widget.ImageView
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

/**
 * Saves contacts / photos into the phone's own contacts database, so the system
 * dialer (and every other app) shows the same photo on an incoming call.
 * Needs WRITE_CONTACTS. Everything stays on-device.
 */
class ContactWriter(context: Context) {
    private val resolver = context.applicationContext.contentResolver

    /** Creates a phone-local contact. Returns its contact id. */
    fun createContact(name: String, number: String, photoJpeg: ByteArray?): Long {
        val ops = arrayListOf(
            ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
                .build(),
            ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                .withValue(ContactsContract.Data.MIMETYPE, StructuredName.CONTENT_ITEM_TYPE)
                .withValue(StructuredName.DISPLAY_NAME, name)
                .build(),
            ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                .withValue(ContactsContract.Data.MIMETYPE, Phone.CONTENT_ITEM_TYPE)
                .withValue(Phone.NUMBER, number)
                .withValue(Phone.TYPE, Phone.TYPE_MOBILE)
                .build()
        )
        val results = resolver.applyBatch(ContactsContract.AUTHORITY, ops)
        val rawId = ContentUris.parseId(results[0].uri ?: throw IllegalStateException("Contact was not created"))
        if (photoJpeg != null) writeRawPhoto(rawId, photoJpeg)
        return contactIdOfRaw(rawId) ?: throw IllegalStateException("Contact was not created")
    }

    /** Sets the photo of an existing contact (first writable raw contact wins). */
    fun setPhoto(contactId: Long, photoJpeg: ByteArray) {
        val rawIds = ArrayList<Long>()
        resolver.query(
            ContactsContract.RawContacts.CONTENT_URI,
            arrayOf(ContactsContract.RawContacts._ID),
            "${ContactsContract.RawContacts.CONTACT_ID}=?", arrayOf(contactId.toString()), null
        )?.use { c -> while (c.moveToNext()) rawIds.add(c.getLong(0)) }

        for (rawId in rawIds) {
            try {
                writeRawPhoto(rawId, photoJpeg)
                return
            } catch (e: Exception) {
                // Read-only account (e.g. a synced app contact); try the next one.
            }
        }
        throw IllegalStateException("This contact's account doesn't allow photo changes.")
    }

    private fun writeRawPhoto(rawId: Long, bytes: ByteArray) {
        val uri = Uri.withAppendedPath(
            ContentUris.withAppendedId(ContactsContract.RawContacts.CONTENT_URI, rawId),
            ContactsContract.RawContacts.DisplayPhoto.CONTENT_DIRECTORY
        )
        val afd = resolver.openAssetFileDescriptor(uri, "rw")
            ?: throw IllegalStateException("Photo storage unavailable")
        afd.use { a -> a.createOutputStream().use { it.write(bytes) } }
    }

    private fun contactIdOfRaw(rawId: Long): Long? {
        resolver.query(
            ContactsContract.RawContacts.CONTENT_URI,
            arrayOf(ContactsContract.RawContacts.CONTACT_ID),
            "${ContactsContract.RawContacts._ID}=?", arrayOf(rawId.toString()), null
        )?.use { c -> if (c.moveToFirst()) return c.getLong(0) }
        return null
    }
}

/** Turns a picked image into a square, 720px max JPEG ready for the contacts database. */
object PhotoPrep {
    fun toJpeg(context: Context, uri: Uri, maxSide: Int = 720): Pair<ByteArray, Bitmap> {
        val source = ImageDecoder.createSource(context.contentResolver, uri)
        val bmp = ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val w = info.size.width
            val h = info.size.height
            val shortSide = minOf(w, h)
            if (shortSide > maxSide) {
                val f = maxSide.toFloat() / shortSide
                decoder.setTargetSize((w * f).toInt().coerceAtLeast(1), (h * f).toInt().coerceAtLeast(1))
            }
        }
        val side = minOf(bmp.width, bmp.height)
        val square = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
        val out = ByteArrayOutputStream()
        square.compress(Bitmap.CompressFormat.JPEG, 90, out)
        return out.toByteArray() to square
    }
}

/** Small async loader + memory cache for contact photos in the list. */
object PhotoLoader {
    private val cache = LruCache<String, Bitmap>(80)
    private val pool = Executors.newFixedThreadPool(2)

    fun clear() = cache.evictAll()

    fun load(view: ImageView, uri: String, done: (Boolean) -> Unit) {
        view.tag = uri
        cache.get(uri)?.let {
            view.setImageBitmap(it)
            done(true)
            return
        }
        val ctx = view.context.applicationContext
        pool.execute {
            val bmp = try {
                val u = Uri.parse(uri)
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (bounds.outWidth / (sample * 2) >= 160) sample *= 2
                ctx.contentResolver.openInputStream(u)?.use {
                    BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
                }
            } catch (e: Exception) {
                null
            }
            view.post {
                if (view.tag == uri) {
                    if (bmp != null) {
                        cache.put(uri, bmp)
                        view.setImageBitmap(bmp)
                    }
                    done(bmp != null)
                }
            }
        }
    }
}
