package com.ashrafcyberx.unknowncallblocker

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.widget.TextView
import java.util.Locale

/** How a contact's name is drawn inside this app. Indexes point into [NameStyles]. */
data class NameStyle(val font: Int = 0, val color: Int = 0, val letters: Int = 0)

object NameStyles {
    val FONT_NAMES = listOf("Classic", "Elegant", "Modern", "Condensed", "Script")
    private val FAMILIES = listOf("sans-serif-medium", "serif", "sans-serif-light", "sans-serif-condensed", "cursive")
    private val BOLD = listOf(true, true, false, true, false)

    /** Index 0 is the app's default text colour. */
    val COLORS = intArrayOf(
        Color.parseColor("#F3F7FB"), Color.parseColor("#E8C77A"), Color.parseColor("#55F5A5"),
        Color.parseColor("#50F4FF"), Color.parseColor("#4F8CFF"), Color.parseColor("#9D8CFF"),
        Color.parseColor("#FFB340"), Color.parseColor("#FF6B62")
    )

    val LETTER_NAMES = listOf("As typed", "Title Case", "UPPERCASE")

    fun format(name: String, style: NameStyle): String = when (style.letters) {
        1 -> name.split(' ').joinToString(" ") { w ->
            w.lowercase(Locale.getDefault()).replaceFirstChar { it.titlecase(Locale.getDefault()) }
        }
        2 -> name.uppercase(Locale.getDefault())
        else -> name
    }

    fun apply(tv: TextView, name: String, style: NameStyle) {
        val f = style.font.coerceIn(0, FAMILIES.lastIndex)
        tv.typeface = Typeface.create(FAMILIES[f], if (BOLD[f]) Typeface.BOLD else Typeface.NORMAL)
        tv.setTextColor(COLORS[style.color.coerceIn(0, COLORS.lastIndex)])
        tv.letterSpacing = if (style.letters == 2) 0.06f else 0f
        tv.text = format(name, style)
    }
}

/** Per-contact name style, stored on-device only (keyed by the system contact id). */
class ContactStyleStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("contact_styles", Context.MODE_PRIVATE)

    fun get(contactId: Long): NameStyle {
        val parts = prefs.getString("c$contactId", null)?.split('|') ?: return NameStyle()
        return NameStyle(
            parts.getOrNull(0)?.toIntOrNull() ?: 0,
            parts.getOrNull(1)?.toIntOrNull() ?: 0,
            parts.getOrNull(2)?.toIntOrNull() ?: 0
        )
    }

    fun set(contactId: Long, s: NameStyle) {
        prefs.edit().putString("c$contactId", "${s.font}|${s.color}|${s.letters}").apply()
    }
}
