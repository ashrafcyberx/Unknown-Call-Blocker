# Unknown Call Blocker — By Ashraf CyberX

Native Android app (Kotlin, Gradle Kotlin DSL) that **lets saved contacts ring and rejects calls from unsaved numbers** using Android's official `CallScreeningService`.

## Status (honest report)
- Source code, resources, manifest, Gradle files and unit tests were written but **NOT compiled or run** by the author's environment (no Gradle, Android SDK, or Kotlin compiler, and no network were available).
- **The APK has not been built or tested on any device.** Expect to build it yourself and fix any small issue Android Studio reports.
- `gradle-wrapper.jar` / `gradlew` scripts are not included (they are binaries that need a download). Android Studio works without them; see below.

## Screens (matches the supplied design)
Splash → Onboarding (first run) → bottom-nav app: **Home** (status ring + switch, today's stats), **Contacts** (search, All/Favorites/Groups, call + more), **Logs** (All/Accepted/Blocked), **Settings**. Extra screens: **Permissions**, **Blocked Numbers** (your own always-block list), **How It Works**, **About Us**.

Differences from the mockup, on purpose:
- No separate "Phone Permission": call screening needs only the Call Screening role + READ_CONTACTS, so no extra permission is requested.
- Call logs are kept by this app (calls it screened). It cannot know call duration (that would need READ_CALL_LOG), so the right side shows the day instead of "2m / 0s". Your phone's own call history is untouched.
- Launcher icon and in-app emblem come from your logo (`store/` has the original and a 512x512 Play Store icon).

## Requirements
Android Studio (Koala or newer), JDK 17, Android SDK 34. Device/emulator: Android 10+ (API 29+).

## Open and build
1. Android Studio → **Open** → select the `UnknownCallBlocker` folder → wait for Gradle sync (needs internet once).
2. Optional wrapper: in a terminal with Gradle 8.7 installed run `gradle wrapper --gradle-version 8.7`.
3. Debug APK: **Build → Build Bundle(s)/APK(s) → Build APK(s)**, or `./gradlew assembleDebug`.
   Output: `app/build/outputs/apk/debug/app-debug.apk`.
4. Unit tests: `./gradlew test`.
5. Release APK: **Build → Generate Signed Bundle / APK** and create your own keystore.

## First-run setup (in the app)
1. Tap **Grant contacts permission**.
2. Tap **Set as call screening app** and confirm the system dialog.
3. Keep **Block unknown numbers** on. Status text shows when protection is active.

## Permissions
- `READ_CONTACTS` only (to check whether a caller is saved). No INTERNET permission; nothing is uploaded; backups are disabled.
- Role `ROLE_CALL_SCREENING` (granted by you through the system dialog).

## How it works
- `UnknownCallScreeningService` receives every call (incoming and outgoing) and only acts on **incoming** ones.
- `CallDecisionEngine` (pure Kotlin) decides: outgoing → allow; blocking off → allow; hidden/private number → per your setting (default allow); no contacts permission → allow; lookup error → allow; saved → allow; otherwise reject.
- Numbers are matched by the system `PhoneLookup`, then a fallback `PhoneNumberMatcher` (ignores formatting, `+`/`00`/leading `0`, compares last up to 10 digits, minimum 7).
- Rejected calls stay in the call log and notifications are kept (`skipCallLog=false`, `skipNotification=false`).
- Non-`tel:` handles (e.g. SIP) are always allowed.

## Testing
Automated (JVM, `./gradlew test`): matcher with/without country code, saved vs unsaved, disabled blocking, missing permission, lookup failure, outgoing calls, hidden callers.

Manual on a real device (cannot be automated reliably):
1. Save a test number in Contacts; call the phone from it → rings.
2. Call from a number not saved → rejected, appears in call log as missed/blocked.
3. Save as `9876543210`, call from `+919876543210` and the reverse → rings.
4. Revoke contacts permission → all calls ring; app shows status warning.
5. Turn off blocking → all calls ring.
6. Dial an unsaved number from this phone → call connects normally.
7. Call with hidden caller ID with the setting off, then on.
8. Reboot the phone and repeat step 2 (service restart).

## Limitations
- An app **cannot** make callers hear "the mobile is switched off". That message is produced by the carrier network. This app only rejects the call on the phone; the caller hears what your operator plays for a rejected call (often busy/unanswered).
- Carrier alternatives (no bypassing): ask your operator about conditional call forwarding to a number that plays a message, or a network-side blocking service.
- Some manufacturers' battery managers may limit background services; exclude the app from battery optimization if screening is missed.
- Emergency calls are never intended to be affected; do not rely on this app for safety-critical filtering.

## Upload to GitHub
```
cd UnknownCallBlocker
git init
git add .
git commit -m "Initial commit: Unknown Call Blocker by Ashraf CyberX"
git branch -M main
git remote add origin https://github.com/<your-username>/UnknownCallBlocker.git
git push -u origin main
```
Create the empty repository on github.com first (no README/license).
