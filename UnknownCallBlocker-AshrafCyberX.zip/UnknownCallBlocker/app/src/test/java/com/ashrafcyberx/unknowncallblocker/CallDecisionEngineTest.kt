package com.ashrafcyberx.unknowncallblocker

import org.junit.Assert.assertEquals
import org.junit.Test

class CallDecisionEngineTest {
    private val contacts = listOf("+91 98765 43210", "0112345678")
    private val lookup: (String) -> Boolean = { n -> contacts.any { PhoneNumberMatcher.matches(n, it) } }

    private fun cfg(
        enabled: Boolean = true,
        perm: Boolean = true,
        hidden: HiddenCallerPolicy = HiddenCallerPolicy.ALLOW
    ) = BlockerConfig(enabled, perm, hidden)

    private fun incoming(number: String?, hidden: Boolean = false) = CallInfo(true, number, hidden)

    @Test fun savedContact_isAllowed_withAndWithoutCountryCode() {
        assertEquals(Decision.ALLOW, CallDecisionEngine.decide(incoming("+919876543210"), cfg(), lookup).decision)
        assertEquals(Decision.ALLOW, CallDecisionEngine.decide(incoming("9876543210"), cfg(), lookup).decision)
    }

    @Test fun unsavedNumber_isRejected() {
        assertEquals(Decision.REJECT, CallDecisionEngine.decide(incoming("+919000000001"), cfg(), lookup).decision)
    }

    @Test fun blockingDisabled_allowsEverything() {
        assertEquals(Decision.ALLOW, CallDecisionEngine.decide(incoming("+919000000001"), cfg(enabled = false), lookup).decision)
    }

    @Test fun missingPermission_failsSafe() {
        assertEquals(Decision.ALLOW, CallDecisionEngine.decide(incoming("+919000000001"), cfg(perm = false), lookup).decision)
    }

    @Test fun lookupError_failsSafe() {
        val result = CallDecisionEngine.decide(incoming("+919000000001"), cfg()) { throw IllegalStateException("boom") }
        assertEquals(Decision.ALLOW, result.decision)
    }

    @Test fun outgoingCalls_neverRejected() {
        val outgoing = CallInfo(isIncoming = false, number = "+919000000001")
        assertEquals(Decision.ALLOW, CallDecisionEngine.decide(outgoing, cfg(), lookup).decision)
    }

    @Test fun hiddenCaller_followsPolicy() {
        assertEquals(Decision.ALLOW, CallDecisionEngine.decide(incoming(null), cfg(), lookup).decision)
        assertEquals(Decision.REJECT, CallDecisionEngine.decide(incoming(null), cfg(hidden = HiddenCallerPolicy.BLOCK), lookup).decision)
        assertEquals(Decision.REJECT, CallDecisionEngine.decide(incoming("", true), cfg(hidden = HiddenCallerPolicy.BLOCK), lookup).decision)
    }

    @Test fun blockList_rejectsEvenSavedContact_andEvenWhenBlockingDisabled() {
        val config = BlockerConfig(false, true, HiddenCallerPolicy.ALLOW, listOf("9876543210"))
        val result = CallDecisionEngine.decide(incoming("+919876543210"), config, lookup)
        assertEquals(Decision.REJECT, result.decision)
    }

    @Test fun blockList_doesNotAffectOutgoing() {
        val config = BlockerConfig(true, true, HiddenCallerPolicy.ALLOW, listOf("9876543210"))
        val outgoing = CallInfo(isIncoming = false, number = "9876543210")
        assertEquals(Decision.ALLOW, CallDecisionEngine.decide(outgoing, config, lookup).decision)
    }
}
