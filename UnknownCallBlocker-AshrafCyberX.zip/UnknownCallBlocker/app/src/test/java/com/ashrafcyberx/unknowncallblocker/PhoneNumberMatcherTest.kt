package com.ashrafcyberx.unknowncallblocker

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PhoneNumberMatcherTest {
    @Test fun normalize_stripsFormatting() {
        assertEquals("+919876543210", PhoneNumberMatcher.normalize("+91 98765-43210"))
        assertEquals("9876543210", PhoneNumberMatcher.normalize("(98765) 43210"))
        assertEquals("+919876543210", PhoneNumberMatcher.normalize("00919876543210"))
        assertEquals("", PhoneNumberMatcher.normalize(null))
        assertEquals("", PhoneNumberMatcher.normalize("  "))
    }

    @Test fun matches_withAndWithoutCountryCode() {
        assertTrue(PhoneNumberMatcher.matches("+919876543210", "9876543210"))
        assertTrue(PhoneNumberMatcher.matches("9876543210", "+91 98765 43210"))
        assertTrue(PhoneNumberMatcher.matches("09876543210", "+919876543210"))
        assertTrue(PhoneNumberMatcher.matches("00919876543210", "9876543210"))
        assertTrue(PhoneNumberMatcher.matches("+14155551234", "415-555-1234"))
    }

    @Test fun matches_differentNumbersDoNotMatch() {
        assertFalse(PhoneNumberMatcher.matches("+919876543210", "9876543211"))
        assertFalse(PhoneNumberMatcher.matches("9876543210", "8876543210"))
        assertFalse(PhoneNumberMatcher.matches(null, "9876543210"))
        assertFalse(PhoneNumberMatcher.matches("", ""))
    }

    @Test fun matches_shortCodesNeedExactMatch() {
        assertTrue(PhoneNumberMatcher.matches("12345", "12345"))
        assertFalse(PhoneNumberMatcher.matches("12345", "9912345"))
    }
}
