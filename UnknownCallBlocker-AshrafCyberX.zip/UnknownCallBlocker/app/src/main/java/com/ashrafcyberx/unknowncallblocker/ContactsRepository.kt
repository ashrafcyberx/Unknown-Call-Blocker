package com.ashrafcyberx.unknowncallblocker

import android.content.Context
import android.net.Uri
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone

data class ContactItem(
    val id: Long,
    val name: String,
    val number: String,
    val starred: Boolean,
    val inGroup: Boolean
)

/** Reads contacts on-device only. Throws on provider failure so callers can fail safe. */
class ContactsRepository(context: Context) {
    private val resolver = context.applicationContext.contentResolver

    fun isSavedContact(number: String): Boolean {
        // 1) System lookup: handles country-code/formatting variants natively.
        val lookupUri = Uri.withAppendedPath(
            ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
            Uri.encode(number)
        )
        val lookupCursor = resolver.query(
            lookupUri, arrayOf(ContactsContract.PhoneLookup._ID), null, null, null
        ) ?: throw IllegalStateException("Contacts provider unavailable")
        lookupCursor.use { if (it.count > 0) return true }

        // 2) Fallback: compare against every stored number with our own normalizer.
        val phoneCursor = resolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        ) ?: throw IllegalStateException("Contacts provider unavailable")
        phoneCursor.use { c ->
            val idx = c.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (c.moveToNext()) {
                if (PhoneNumberMatcher.matches(number, c.getString(idx))) return true
            }
        }
        return false
    }

    /** Display name of the contact owning [number], or null. */
    fun displayName(number: String): String? {
        val uri = Uri.withAppendedPath(
            ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
            Uri.encode(number)
        )
        resolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
            ?.use { c ->
                if (c.moveToFirst()) return c.getString(0)
            }
        return null
    }

    /** All contacts that have a phone number, sorted by name. */
    fun listContacts(): List<ContactItem> {
        val groupIds = HashSet<Long>()
        try {
            resolver.query(
                ContactsContract.Data.CONTENT_URI,
                arrayOf(ContactsContract.Data.CONTACT_ID),
                "${ContactsContract.Data.MIMETYPE}=?",
                arrayOf(ContactsContract.CommonDataKinds.GroupMembership.CONTENT_ITEM_TYPE),
                null
            )?.use { c ->
                val i = c.getColumnIndexOrThrow(ContactsContract.Data.CONTACT_ID)
                while (c.moveToNext()) groupIds.add(c.getLong(i))
            }
        } catch (e: Exception) {
            // Groups are optional; ignore failures.
        }

        val cursor = resolver.query(
            Phone.CONTENT_URI,
            arrayOf(Phone.CONTACT_ID, Phone.DISPLAY_NAME, Phone.NUMBER, Phone.STARRED),
            null, null,
            "${Phone.DISPLAY_NAME} COLLATE LOCALIZED ASC"
        ) ?: throw IllegalStateException("Contacts provider unavailable")

        val result = ArrayList<ContactItem>()
        val seen = HashSet<String>()
        cursor.use { c ->
            val iId = c.getColumnIndexOrThrow(Phone.CONTACT_ID)
            val iName = c.getColumnIndexOrThrow(Phone.DISPLAY_NAME)
            val iNum = c.getColumnIndexOrThrow(Phone.NUMBER)
            val iStar = c.getColumnIndexOrThrow(Phone.STARRED)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val number = c.getString(iNum) ?: continue
                val key = "$id|${PhoneNumberMatcher.digitsOnly(number)}"
                if (!seen.add(key)) continue
                result.add(
                    ContactItem(
                        id = id,
                        name = c.getString(iName)?.takeIf { it.isNotBlank() } ?: number,
                        number = number,
                        starred = c.getInt(iStar) == 1,
                        inGroup = groupIds.contains(id)
                    )
                )
            }
        }
        return result
    }
}
