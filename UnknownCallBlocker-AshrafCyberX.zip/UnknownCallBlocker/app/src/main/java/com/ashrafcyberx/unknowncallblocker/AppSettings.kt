package com.ashrafcyberx.unknowncallblocker

import android.content.Context
import android.content.SharedPreferences

/** Persistent, on-device-only preferences. */
class AppSettings(context: Context) {
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    var blockingEnabled: Boolean
        get() = prefs.getBoolean(KEY_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_ENABLED, value).apply()

    var hiddenCallerPolicy: HiddenCallerPolicy
        get() = if (prefs.getBoolean(KEY_BLOCK_HIDDEN, false)) HiddenCallerPolicy.BLOCK else HiddenCallerPolicy.ALLOW
        set(value) = prefs.edit().putBoolean(KEY_BLOCK_HIDDEN, value == HiddenCallerPolicy.BLOCK).apply()

    var onboardingDone: Boolean
        get() = prefs.getBoolean(KEY_ONBOARDING, false)
        set(value) = prefs.edit().putBoolean(KEY_ONBOARDING, value).apply()

    var welcomeShown: Boolean
        get() = prefs.getBoolean(KEY_WELCOME, false)
        set(value) = prefs.edit().putBoolean(KEY_WELCOME, value).apply()

    private companion object {
        const val PREFS = "unknown_call_blocker_prefs"
        const val KEY_ENABLED = "blocking_enabled"
        const val KEY_BLOCK_HIDDEN = "block_hidden_callers"
        const val KEY_ONBOARDING = "onboarding_done"
        const val KEY_WELCOME = "welcome_dialog_shown"
    }
}
