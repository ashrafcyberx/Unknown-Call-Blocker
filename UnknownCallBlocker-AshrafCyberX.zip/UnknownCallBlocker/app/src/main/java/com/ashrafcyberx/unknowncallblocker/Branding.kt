package com.ashrafcyberx.unknowncallblocker

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

/** Official Ashraf CyberX links. They open in the browser/app; no INTERNET permission is needed. */
object Branding {
    const val YOUTUBE = "https://youtube.com/@ashraf_cyberx?si=Uw3PAMKLQG_O84zV"
    const val INSTAGRAM = "https://www.instagram.com/ashraf_cyberx?stkn=aGEyNG5lZm5namFx"
    const val TELEGRAM = "https://t.me/Ashraf_CyberX"
    const val WHATSAPP = "https://whatsapp.com/channel/0029VbDr1TL8kyyHB4MATv3Q"

    fun open(context: Context, url: String) {
        try {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(context, "No app found to open this link.", Toast.LENGTH_SHORT).show()
        }
    }
}
