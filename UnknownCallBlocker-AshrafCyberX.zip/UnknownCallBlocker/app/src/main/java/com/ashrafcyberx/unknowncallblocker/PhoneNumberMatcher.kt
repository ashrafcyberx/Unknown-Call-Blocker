package com.ashrafcyberx.unknowncallblocker

/**
 * Pure-Kotlin phone number normalization and comparison (no Android dependencies, unit-testable).
 *
 * Matching rules:
 *  1. Formatting is ignored (spaces, dashes, brackets, dots).
 *  2. "00" international prefix is treated like "+".
 *  3. Exact match of normalized values is a match.
 *  4. Otherwise, leading zeros (domestic trunk prefix) and "+" are dropped and the last
 *     min(10, shorter length) digits are compared, provided at least 7 digits are compared.
 *     This makes "+919876543210", "919876543210", "09876543210" and "9876543210" equal.
 */
object PhoneNumberMatcher {
    private const val MIN_SUFFIX_DIGITS = 7
    private const val MAX_SUFFIX_DIGITS = 10

    fun digitsOnly(raw: String?): String = raw?.filter { it in '0'..'9' } ?: ""

    /** Returns "+<digits>" for international numbers, "<digits>" otherwise, or "" if no digits. */
    fun normalize(raw: String?): String {
        if (raw.isNullOrBlank()) return ""
        val trimmed = raw.trim()
        val digits = digitsOnly(trimmed)
        if (digits.isEmpty()) return ""
        return when {
            trimmed.startsWith("+") -> "+$digits"
            trimmed.startsWith("00") && digits.length > 2 -> "+${digits.substring(2)}"
            else -> digits
        }
    }

    fun matches(a: String?, b: String?): Boolean {
        val na = normalize(a)
        val nb = normalize(b)
        if (na.isEmpty() || nb.isEmpty()) return false
        if (na == nb) return true

        val ta = na.removePrefix("+").trimStart('0')
        val tb = nb.removePrefix("+").trimStart('0')
        val n = minOf(ta.length, tb.length, MAX_SUFFIX_DIGITS)
        if (n < MIN_SUFFIX_DIGITS) return false
        return ta.takeLast(n) == tb.takeLast(n)
    }
}
