package com.ashrafcyberx.unknowncallblocker

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.ashrafcyberx.unknowncallblocker.databinding.ActivityMainBinding
import com.ashrafcyberx.unknowncallblocker.databinding.DialogWelcomeBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/** Hosts the four bottom-navigation tabs: Home, Contacts, Logs, Settings. */
class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.bottomNav.setOnItemSelectedListener { item ->
            val fragment: Fragment = when (item.itemId) {
                R.id.nav_contacts -> ContactsFragment()
                R.id.nav_logs -> LogsFragment()
                R.id.nav_settings -> SettingsFragment()
                else -> HomeFragment()
            }
            supportFragmentManager.beginTransaction()
                .replace(R.id.container, fragment)
                .commit()
            true
        }
        if (savedInstanceState == null) {
            binding.bottomNav.selectedItemId = R.id.nav_home
            maybeShowWelcome()
        }
    }

    /** First launch only: invite the user to read about the developer. */
    private fun maybeShowWelcome() {
        val settings = AppSettings(this)
        if (settings.welcomeShown) return
        settings.welcomeShown = true
        val dialogBinding = DialogWelcomeBinding.inflate(layoutInflater)
        val dialog = MaterialAlertDialogBuilder(this)
            .setView(dialogBinding.root)
            .create()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialogBinding.btnDevInfo.setOnClickListener {
            dialog.dismiss()
            startActivity(Intent(this, DeveloperActivity::class.java))
        }
        dialogBinding.btnLater.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    fun select(itemId: Int) {
        binding.bottomNav.selectedItemId = itemId
    }
}
