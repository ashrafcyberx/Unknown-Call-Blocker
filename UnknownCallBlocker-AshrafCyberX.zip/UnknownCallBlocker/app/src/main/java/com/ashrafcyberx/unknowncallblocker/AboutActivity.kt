package com.ashrafcyberx.unknowncallblocker

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.ashrafcyberx.unknowncallblocker.databinding.ActivityAboutBinding

class AboutActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityAboutBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnBack.setOnClickListener { finish() }
        binding.btnDeveloper.setOnClickListener { startActivity(Intent(this, DeveloperActivity::class.java)) }
        binding.textVersion.text = "Version ${appVersion()}"
    }
}

/** Version name from the installed package (e.g. "1.0.0"). */
fun android.content.Context.appVersion(): String =
    try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: "1.0.0"
    } catch (e: Exception) {
        "1.0.0"
    }
