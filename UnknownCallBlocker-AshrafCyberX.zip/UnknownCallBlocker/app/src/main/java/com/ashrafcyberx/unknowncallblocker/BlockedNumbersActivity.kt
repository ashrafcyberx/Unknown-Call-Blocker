package com.ashrafcyberx.unknowncallblocker

import android.os.Bundle
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ashrafcyberx.unknowncallblocker.databinding.ActivityBlockedBinding
import com.ashrafcyberx.unknowncallblocker.databinding.ItemBlockedBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class BlockedNumbersActivity : AppCompatActivity() {
    private lateinit var binding: ActivityBlockedBinding
    private lateinit var store: BlockedNumbersStore
    private val adapter = BlockedAdapter { number ->
        store.remove(number)
        reload()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBlockedBinding.inflate(layoutInflater)
        setContentView(binding.root)
        store = BlockedNumbersStore(this)

        binding.list.layoutManager = LinearLayoutManager(this)
        binding.list.adapter = adapter
        binding.btnBack.setOnClickListener { finish() }
        binding.btnAction.setOnClickListener { showAddDialog() }
        binding.btnAddNumber.setOnClickListener { showAddDialog() }
        reload()
    }

    private fun reload() {
        val items = store.list()
        adapter.submit(items)
        binding.emptyBox.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        binding.list.visibility = if (items.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun showAddDialog() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_PHONE
            hint = "Phone number, e.g. +919876543210"
        }
        val pad = (20 * resources.displayMetrics.density).toInt()
        val frame = FrameLayout(this).apply {
            setPadding(pad, pad / 2, pad, 0)
            addView(input)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Block a number")
            .setView(frame)
            .setPositiveButton("Block") { _, _ ->
                if (store.add(input.text.toString())) {
                    reload()
                } else {
                    Toast.makeText(this, "Enter a valid number that is not already blocked.", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}

class BlockedAdapter(private val onRemove: (String) -> Unit) :
    RecyclerView.Adapter<BlockedAdapter.VH>() {
    private var items: List<String> = emptyList()

    fun submit(list: List<String>) {
        items = list
        notifyDataSetChanged()
    }

    class VH(val b: ItemBlockedBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemBlockedBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val number = items[position]
        holder.b.textNumber.text = number
        holder.b.btnRemove.setOnClickListener { onRemove(number) }
    }
}
