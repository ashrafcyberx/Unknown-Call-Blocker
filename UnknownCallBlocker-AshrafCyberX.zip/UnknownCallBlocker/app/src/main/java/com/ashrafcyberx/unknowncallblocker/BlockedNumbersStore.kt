package com.ashrafcyberx.unknowncallblocker

import android.content.Context

/** User-managed list of numbers that are always rejected. Stored on-device only. */
class BlockedNumbersStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("blocked_numbers", Context.MODE_PRIVATE)

    fun list(): List<String> =
        (prefs.getString(KEY, "") ?: "").split('\n').filter { it.isNotBlank() }

    /** Returns false if the number is empty/invalid or already present. */
    fun add(raw: String): Boolean {
        val number = PhoneNumberMatcher.normalize(raw)
        if (PhoneNumberMatcher.digitsOnly(number).length < 3) return false
        val current = list()
        if (current.any { PhoneNumberMatcher.matches(it, number) }) return false
        save(current + number)
        return true
    }

    fun remove(number: String) = save(list().filter { it != number })

    private fun save(items: List<String>) {
        prefs.edit().putString(KEY, items.joinToString("\n")).apply()
    }

    private companion object {
        const val KEY = "numbers"
    }
}
