package com.ashrafcyberx.unknowncallblocker

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.ashrafcyberx.unknowncallblocker.databinding.ActivityDeveloperBinding

class DeveloperActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityDeveloperBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnBack.setOnClickListener { finish() }
        binding.rowYoutube.setOnClickListener { Branding.open(this, Branding.YOUTUBE) }
        binding.rowInstagram.setOnClickListener { Branding.open(this, Branding.INSTAGRAM) }
        binding.rowTelegram.setOnClickListener { Branding.open(this, Branding.TELEGRAM) }
        binding.rowWhatsapp.setOnClickListener { Branding.open(this, Branding.WHATSAPP) }
    }
}
