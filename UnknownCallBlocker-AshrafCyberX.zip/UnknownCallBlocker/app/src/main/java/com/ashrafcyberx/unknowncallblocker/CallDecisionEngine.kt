package com.ashrafcyberx.unknowncallblocker

enum class HiddenCallerPolicy { ALLOW, BLOCK }

enum class Decision { ALLOW, REJECT }

data class CallInfo(
    val isIncoming: Boolean,
    /** Raw dialed/incoming number, or null/blank when private, hidden or unavailable. */
    val number: String?,
    val isHiddenOrRestricted: Boolean = false
)

data class BlockerConfig(
    val blockingEnabled: Boolean,
    val hasContactsPermission: Boolean,
    val hiddenCallerPolicy: HiddenCallerPolicy,
    /** Numbers the user explicitly asked to always block. */
    val blockedNumbers: List<String> = emptyList()
)

data class DecisionResult(val decision: Decision, val reason: String)

/**
 * Pure decision logic. The contact lookup is injected so it can be unit-tested.
 * Principle: anything uncertain (no permission, lookup error) results in ALLOW.
 */
object CallDecisionEngine {

    fun decide(
        call: CallInfo,
        config: BlockerConfig,
        isSavedContact: (String) -> Boolean
    ): DecisionResult {
        if (!call.isIncoming) return DecisionResult(Decision.ALLOW, "Not an incoming call")

        val number = call.number
        val hasNumber = !number.isNullOrBlank() && !call.isHiddenOrRestricted &&
            PhoneNumberMatcher.digitsOnly(number).isNotEmpty()

        // The user's own block list always wins (even over saved contacts).
        if (hasNumber && config.blockedNumbers.any { PhoneNumberMatcher.matches(number, it) }) {
            return DecisionResult(Decision.REJECT, "Number is on your block list")
        }

        if (!config.blockingEnabled) return DecisionResult(Decision.ALLOW, "Blocking disabled")

        if (!hasNumber) {
            return when (config.hiddenCallerPolicy) {
                HiddenCallerPolicy.BLOCK -> DecisionResult(Decision.REJECT, "Hidden caller blocked by setting")
                HiddenCallerPolicy.ALLOW -> DecisionResult(Decision.ALLOW, "Hidden caller allowed by setting")
            }
        }

        if (!config.hasContactsPermission) {
            return DecisionResult(Decision.ALLOW, "Contacts permission missing (fail-safe)")
        }

        return try {
            if (isSavedContact(number!!)) {
                DecisionResult(Decision.ALLOW, "Saved contact")
            } else {
                DecisionResult(Decision.REJECT, "Unknown number")
            }
        } catch (t: Throwable) {
            DecisionResult(Decision.ALLOW, "Contact lookup failed (fail-safe)")
        }
    }
}
