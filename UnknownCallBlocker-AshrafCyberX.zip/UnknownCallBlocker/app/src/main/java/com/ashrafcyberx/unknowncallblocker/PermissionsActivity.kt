package com.ashrafcyberx.unknowncallblocker

import android.Manifest
import android.content.Intent
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.ashrafcyberx.unknowncallblocker.databinding.ActivityPermissionsBinding

class PermissionsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityPermissionsBinding

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (!granted && !shouldShowRequestPermissionRationale(Manifest.permission.READ_CONTACTS)) {
                // Permanently denied: send the user to the app settings page.
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
            }
            refresh()
        }

    private val roleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPermissionsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnBack.setOnClickListener { finish() }
        binding.btnContacts.setOnClickListener {
            permissionLauncher.launch(Manifest.permission.READ_CONTACTS)
        }
        binding.btnRole.setOnClickListener {
            val intent = Setup.roleIntent(this)
            if (intent == null) {
                Toast.makeText(this, "Call screening role is not available on this device.", Toast.LENGTH_LONG).show()
            } else {
                roleLauncher.launch(intent)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        applyState(binding.btnContacts, Setup.hasContacts(this), "Grant", "Granted")
        applyState(binding.btnRole, Setup.hasRole(this), "Go to Settings", "Selected")
    }

    private fun applyState(button: MaterialButton, done: Boolean, todoText: String, doneText: String) {
        val accent = getColor(R.color.accent)
        if (done) {
            button.text = doneText
            button.setIconResource(R.drawable.ic_check)
            button.iconTint = ColorStateList.valueOf(getColor(R.color.bg))
            button.setBackgroundColor(accent)
            button.setTextColor(getColor(R.color.bg))
            button.isClickable = false
        } else {
            button.text = todoText
            button.icon = null
            button.isClickable = true
        }
    }
}
