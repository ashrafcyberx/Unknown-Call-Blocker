package com.ashrafcyberx.unknowncallblocker

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.ashrafcyberx.unknowncallblocker.databinding.ActivityHowItWorksBinding

class HowItWorksActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityHowItWorksBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnBack.setOnClickListener { finish() }
    }
}
