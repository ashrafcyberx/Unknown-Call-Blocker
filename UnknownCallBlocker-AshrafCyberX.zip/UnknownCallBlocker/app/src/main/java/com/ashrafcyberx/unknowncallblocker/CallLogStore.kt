package com.ashrafcyberx.unknowncallblocker

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/** [number] is empty for private/hidden callers. [name] is set for saved contacts. */
data class LogEntry(val number: String, val name: String?, val blocked: Boolean, val time: Long)

/** Small on-device log of calls this app screened (newest first, max 200). */
class CallLogStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("call_log", Context.MODE_PRIVATE)

    fun add(entry: LogEntry) = synchronized(LOCK) {
        val list = read()
        list.add(0, entry)
        write(list.take(MAX))
    }

    fun all(): List<LogEntry> = synchronized(LOCK) { read() }

    fun clear() = synchronized(LOCK) { prefs.edit().remove(KEY).apply() }

    /** Returns (total, blocked) for today. */
    fun todayCounts(): Pair<Int, Int> {
        val start = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val today = all().filter { it.time >= start }
        return today.size to today.count { it.blocked }
    }

    private fun read(): MutableList<LogEntry> {
        val raw = prefs.getString(KEY, null) ?: return mutableListOf()
        return try {
            val arr = JSONArray(raw)
            val out = ArrayList<LogEntry>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    LogEntry(
                        number = o.getString("n"),
                        name = if (o.isNull("nm")) null else o.getString("nm"),
                        blocked = o.getBoolean("b"),
                        time = o.getLong("t")
                    )
                )
            }
            out
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    private fun write(list: List<LogEntry>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("n", it.number)
                    .put("nm", it.name ?: JSONObject.NULL)
                    .put("b", it.blocked)
                    .put("t", it.time)
            )
        }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    private companion object {
        const val KEY = "entries"
        const val MAX = 200
        val LOCK = Any()
    }
}
