package com.ashrafcyberx.unknowncallblocker

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.view.animation.LinearInterpolator

/** Shared clock so every card's glass shine sweeps from one animator. */
object GlassClock {
    private val cards = LinkedHashSet<GlassCard>()
    private var animator: ValueAnimator? = null

    fun register(card: GlassCard) {
        cards.add(card)
        if (animator == null && ValueAnimator.areAnimatorsEnabled()) start()
    }

    fun unregister(card: GlassCard) {
        cards.remove(card)
        if (cards.isEmpty()) {
            animator?.cancel()
            animator = null
        }
    }

    private fun start() {
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 10000L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { va ->
                val p = va.animatedValue as Float
                for (c in cards.toTypedArray()) c.onShineTick(p)
            }
            start()
        }
    }
}

/**
 * Frosted-glass container: translucent gradient fill, bright gradient edge,
 * top highlight and a slow diagonal shine sweep (matches the HTML design).
 */
open class GlassCard @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {

    private var radius = dpf(20f)
    private var shineEnabled = true
    private var dark = false
    private var shineOffset = 0f

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pressPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hiPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shinePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val shineMatrix = Matrix()
    private var shineShader: LinearGradient? = null
    private var bandW = 0f
    private var shineX = 0f
    private var shineActive = false

    init {
        if (attrs != null) {
            val a = context.obtainStyledAttributes(attrs, R.styleable.GlassCard, defStyleAttr, 0)
            radius = a.getDimension(R.styleable.GlassCard_glassRadius, radius)
            shineEnabled = a.getBoolean(R.styleable.GlassCard_glassShine, true)
            dark = a.getBoolean(R.styleable.GlassCard_glassDark, false)
            shineOffset = a.getFloat(R.styleable.GlassCard_glassOffset, 0f)
            a.recycle()
        }
        setWillNotDraw(false)
        strokePaint.style = Paint.Style.STROKE
        strokePaint.strokeWidth = dpf(1f)
        hiPaint.style = Paint.Style.STROKE
        hiPaint.strokeWidth = dpf(1f)
        pressPaint.color = Color.argb(14, 255, 255, 255)
        basePaint.color = if (dark) Color.TRANSPARENT else Color.argb(40, 8, 14, 22)
        clipToOutline = true
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radius)
            }
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val wf = w.toFloat()
        val hf = h.toFloat()
        val inset = strokePaint.strokeWidth / 2f
        rect.set(inset, inset, wf - inset, hf - inset)

        if (dark) {
            fillPaint.shader = cssGradient(
                wf, hf, 145f,
                intArrayOf(Color.argb(214, 26, 42, 58), Color.argb(214, 8, 15, 24)), null
            )
            strokePaint.shader = null
            strokePaint.color = Color.argb(36, 255, 255, 255)
        } else {
            fillPaint.shader = cssGradient(
                wf, hf, 145f,
                intArrayOf(
                    Color.argb(27, 255, 255, 255),
                    Color.argb(7, 255, 255, 255),
                    Color.argb(14, 91, 140, 255)
                ),
                floatArrayOf(0f, 0.48f, 1f)
            )
            strokePaint.shader = cssGradient(
                wf, hf, 135f,
                intArrayOf(
                    Color.argb(97, 255, 255, 255),
                    Color.argb(64, 80, 244, 255),
                    Color.argb(11, 255, 255, 255),
                    Color.argb(56, 85, 245, 165)
                ),
                floatArrayOf(0f, 0.32f, 0.65f, 1f)
            )
        }
        // top edge highlight (inset 0 1px 0 white)
        val hiPeak = if (dark) Color.argb(56, 255, 255, 255) else Color.argb(48, 255, 255, 255)
        hiPaint.shader = LinearGradient(
            radius, 0f, (wf - radius).coerceAtLeast(radius + 1f), 0f,
            intArrayOf(Color.argb(0, 255, 255, 255), hiPeak, Color.argb(0, 255, 255, 255)),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        bandW = wf * 0.9f
        shineShader = LinearGradient(
            0f, 0f, bandW, 0f,
            intArrayOf(Color.argb(0, 255, 255, 255), Color.argb(26, 255, 255, 255), Color.argb(0, 255, 255, 255)),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        invalidateOutline()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (rect.isEmpty) return
        if (!dark) canvas.drawRoundRect(rect, radius, radius, basePaint)
        canvas.drawRoundRect(rect, radius, radius, fillPaint)
        if (isPressed && isClickable) canvas.drawRoundRect(rect, radius, radius, pressPaint)
    }

    override fun dispatchDraw(canvas: Canvas) {
        super.dispatchDraw(canvas)
        if (rect.isEmpty) return
        if (shineActive) {
            val s = shineShader
            if (s != null) {
                shineMatrix.setTranslate(shineX - bandW / 2f, 0f)
                shineMatrix.postRotate(-20f, shineX, height / 2f)
                s.setLocalMatrix(shineMatrix)
                shinePaint.shader = s
                canvas.drawRoundRect(rect, radius, radius, shinePaint)
            }
        }
        canvas.drawRoundRect(rect, radius, radius, strokePaint)
        canvas.drawLine(radius, 0.5f * hiPaint.strokeWidth, (width - radius).coerceAtLeast(radius + 1f), 0.5f * hiPaint.strokeWidth, hiPaint)
    }

    override fun drawableStateChanged() {
        super.drawableStateChanged()
        invalidate()
    }

    internal fun onShineTick(global: Float) {
        if (!shineEnabled || width == 0) return
        val ph = (global + shineOffset) % 1f
        val was = shineActive
        shineActive = ph >= 0.55f
        if (shineActive) {
            val u = (ph - 0.55f) / 0.45f
            shineX = -1.5f * width + 4f * width * u
            invalidate()
        } else if (was) {
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (shineEnabled) GlassClock.register(this)
    }

    override fun onDetachedFromWindow() {
        GlassClock.unregister(this)
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (!shineEnabled) return
        if (visibility == View.VISIBLE) {
            if (isAttachedToWindow) GlassClock.register(this)
        } else {
            GlassClock.unregister(this)
        }
    }
}
