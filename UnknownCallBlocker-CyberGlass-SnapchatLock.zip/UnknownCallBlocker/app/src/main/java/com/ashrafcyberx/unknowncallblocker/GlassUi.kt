package com.ashrafcyberx.unknowncallblocker

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.widget.TextView
import androidx.core.graphics.ColorUtils

fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density
fun View.dpf(v: Float): Float = context.dpf(v)

/** CSS-style `linear-gradient(<deg>, ...)` for a w x h box. */
fun cssGradient(w: Float, h: Float, deg: Float, colors: IntArray, pos: FloatArray?): LinearGradient {
    val a = Math.toRadians(deg.toDouble())
    val dx = Math.sin(a).toFloat()
    val dy = (-Math.cos(a)).toFloat()
    val len = Math.abs(w * dx) + Math.abs(h * dy)
    val cx = w / 2f
    val cy = h / 2f
    return LinearGradient(
        cx - dx * len / 2f, cy - dy * len / 2f,
        cx + dx * len / 2f, cy + dy * len / 2f,
        colors, pos, Shader.TileMode.CLAMP
    )
}

object GlassUi {
    fun withAlpha(color: Int, alpha: Float): Int =
        ColorUtils.setAlphaComponent(color, (alpha * 255f).toInt().coerceIn(0, 255))

    /** Soft tinted tile / avatar: translucent fill + thin coloured border. */
    fun tinted(
        ctx: Context, color: Int, radiusDp: Float, oval: Boolean = false,
        fill: Float = 0.14f, line: Float = 0.28f
    ): GradientDrawable = GradientDrawable().apply {
        shape = if (oval) GradientDrawable.OVAL else GradientDrawable.RECTANGLE
        if (!oval) cornerRadius = ctx.dpf(radiusDp)
        setColor(withAlpha(color, fill))
        setStroke(ctx.dpf(1f).toInt().coerceAtLeast(1), withAlpha(color, line))
    }

    /** Small status pill ("Granted", "Selected") in the given colour. */
    fun styleTag(v: TextView, color: Int) {
        v.setTextColor(color)
        v.compoundDrawableTintList = ColorStateList.valueOf(color)
        v.background = tinted(v.context, color, 20f, fill = 0.05f, line = 0.14f)
    }
}
