package com.ashrafcyberx.unknowncallblocker

import android.content.Context
import android.content.SharedPreferences

/** What a rejected caller should hear. Final sound is produced by the carrier network. */
enum class RejectStyle { BUSY, SWITCH_OFF }

/** Persistent, on-device-only preferences. */
class AppSettings(context: Context) {
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    var blockingEnabled: Boolean
        get() = prefs.getBoolean(KEY_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_ENABLED, value).apply()

    var hiddenCallerPolicy: HiddenCallerPolicy
        get() = if (prefs.getBoolean(KEY_BLOCK_HIDDEN, false)) HiddenCallerPolicy.BLOCK else HiddenCallerPolicy.ALLOW
        set(value) = prefs.edit().putBoolean(KEY_BLOCK_HIDDEN, value == HiddenCallerPolicy.BLOCK).apply()

    var rejectStyle: RejectStyle
        get() = if (prefs.getString(KEY_STYLE, null) == RejectStyle.SWITCH_OFF.name) RejectStyle.SWITCH_OFF else RejectStyle.BUSY
        set(value) = prefs.edit().putString(KEY_STYLE, value.name).apply()

    /** Number used for the one-time "switched off" carrier forwarding setup. */
    var forwardNumber: String
        get() = prefs.getString(KEY_FORWARD, "") ?: ""
        set(value) = prefs.edit().putString(KEY_FORWARD, value).apply()

    var onboardingDone: Boolean
        get() = prefs.getBoolean(KEY_ONBOARDING, false)
        set(value) = prefs.edit().putBoolean(KEY_ONBOARDING, value).apply()

    private companion object {
        const val PREFS = "unknown_call_blocker_prefs"
        const val KEY_ENABLED = "blocking_enabled"
        const val KEY_BLOCK_HIDDEN = "block_hidden_callers"
        const val KEY_STYLE = "reject_style"
        const val KEY_FORWARD = "forward_number"
        const val KEY_ONBOARDING = "onboarding_done"
    }
}
