package com.ashrafcyberx.unknowncallblocker

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.animation.OvershootInterpolator
import android.widget.CompoundButton
import androidx.core.graphics.ColorUtils

/** iOS-style switch: green when on, stretchy white thumb. Behaves like any CompoundButton. */
class GlassSwitch @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : CompoundButton(context, attrs, defStyleAttr) {

    private var ready = false // CompoundButton's constructor calls setChecked() before our fields exist
    private var pos = 0f
    private var press = 0f
    private var posAnim: ValueAnimator? = null
    private var pressAnim: ValueAnimator? = null
    private val drawPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val offTrack = Color.argb(82, 120, 120, 128)
    private val onTrack = Color.rgb(85, 245, 165)

    init {
        ready = true
        pos = if (isChecked) 1f else 0f
        isClickable = true
        isFocusable = true
    }

    override fun setChecked(checked: Boolean) {
        val was = isChecked
        super.setChecked(checked)
        if (!ready) return
        if (was == checked) return
        val target = if (checked) 1f else 0f
        posAnim?.cancel()
        if (isAttachedToWindow && isShown && ValueAnimator.areAnimatorsEnabled()) {
            posAnim = ValueAnimator.ofFloat(pos, target).apply {
                duration = 400L
                interpolator = OvershootInterpolator(1.4f)
                addUpdateListener { pos = it.animatedValue as Float; invalidate() }
                start()
            }
        } else {
            pos = target
            invalidate()
        }
    }

    private var lastPressed = false

    override fun drawableStateChanged() {
        super.drawableStateChanged()
        if (!ready) return
        val pressedNow = drawableState.contains(android.R.attr.state_pressed)
        if (pressedNow == lastPressed) return
        lastPressed = pressedNow
        pressAnim?.cancel()
        pressAnim = ValueAnimator.ofFloat(press, if (pressedNow) 1f else 0f).apply {
            duration = 150L
            addUpdateListener { press = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(dpf(48f).toInt(), dpf(29f).toInt())
    }

    override fun onDraw(canvas: Canvas) {
        val d = dpf(1f)
        val w = 48f * d
        val h = 29f * d
        val t = pos.coerceIn(0f, 1f)

        rect.set(0f, 0f, w, h)
        drawPaint.style = Paint.Style.FILL
        drawPaint.color = ColorUtils.blendARGB(offTrack, onTrack, t)
        canvas.drawRoundRect(rect, h / 2f, h / 2f, drawPaint)
        drawPaint.style = Paint.Style.STROKE
        drawPaint.strokeWidth = d
        drawPaint.color = Color.argb(11, 255, 255, 255)
        rect.set(0.5f * d, 0.5f * d, w - 0.5f * d, h - 0.5f * d)
        canvas.drawRoundRect(rect, h / 2f, h / 2f, drawPaint)

        val thumbW = 23f * d + 4f * d * press
        val left = 2f * d + 19f * d * pos - 4f * d * press * t
        rect.set(left, 3f * d, left + thumbW, 26f * d)
        drawPaint.style = Paint.Style.FILL
        drawPaint.color = Color.argb(70, 0, 0, 0)
        val shadow = RectF(rect.left, rect.top + 1.5f * d, rect.right, rect.bottom + 1.5f * d)
        canvas.drawRoundRect(shadow, 11.5f * d, 11.5f * d, drawPaint)
        drawPaint.color = Color.WHITE
        canvas.drawRoundRect(rect, 11.5f * d, 11.5f * d, drawPaint)
    }
}
