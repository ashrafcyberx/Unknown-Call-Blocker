package com.ashrafcyberx.unknowncallblocker

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.exp

/**
 * Full-screen backdrop: dark gradient, soft colour orbs (two of them drifting),
 * and a faint masked grid. Orbs switch from cyan/green (protected) to red (off).
 */
class GlowBackground @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var off = 0f // 0 = protection on, 1 = off
    private var offAnim: ValueAnimator? = null
    private var timeAnim: ValueAnimator? = null
    private var p1 = 0f
    private var p2 = 0f
    private var lastTick = 0L

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gridPaint = Paint()
    private var base: Shader? = null
    private var grid: Bitmap? = null

    private val shaderCache = HashMap<Int, RadialGradient>()

    private fun unitGlow(color: Int): RadialGradient = shaderCache.getOrPut(color) {
        val steps = 9
        val colors = IntArray(steps)
        val pos = FloatArray(steps)
        for (i in 0 until steps) {
            val t = i / (steps - 1).toFloat()
            val a = (255f * 0.85f * exp((-3.2f * t * t).toDouble()).toFloat()).toInt().coerceIn(0, 255)
            colors[i] = Color.argb(a, Color.red(color), Color.green(color), Color.blue(color))
            pos[i] = t
        }
        colors[steps - 1] = Color.argb(0, Color.red(color), Color.green(color), Color.blue(color))
        RadialGradient(0f, 0f, 1f, colors, pos, Shader.TileMode.CLAMP)
    }

    /** Orb of CSS size `size`dp; the visible glow extends ~2x that radius. */
    private fun orb(c: Canvas, cx: Float, cy: Float, sizeDp: Float, color: Int, alpha: Float, scale: Float = 1f) {
        if (alpha <= 0.004f) return
        val r = dpf(sizeDp) / 2f * 2.0f * scale
        paint.shader = unitGlow(color)
        paint.alpha = (alpha * 255f).toInt().coerceIn(0, 255)
        c.save()
        c.translate(cx, cy)
        c.scale(r, r)
        c.drawCircle(0f, 0f, 1f, paint)
        c.restore()
        paint.shader = null
        paint.alpha = 255
    }

    fun setProtectionOn(on: Boolean, animate: Boolean) {
        val target = if (on) 0f else 1f
        offAnim?.cancel()
        if (!animate || !isAttachedToWindow) {
            off = target
            invalidate()
            return
        }
        offAnim = ValueAnimator.ofFloat(off, target).apply {
            duration = 1000L
            addUpdateListener {
                off = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w == 0 || h == 0) return
        base = cssGradient(
            w.toFloat(), h.toFloat(), 160f,
            intArrayOf(Color.rgb(10, 19, 30), Color.rgb(3, 7, 12)), null
        )
        buildGrid(w, h)
    }

    private fun buildGrid(w: Int, h: Int) {
        grid?.recycle()
        val gh = (h * 0.75f).toInt().coerceAtLeast(1)
        val bmp = Bitmap.createBitmap(w, gh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val step = dpf(34f)
        val line = Paint().apply { color = Color.argb(7, 255, 255, 255); strokeWidth = dpf(1f) }
        var x = 0f
        while (x < w) { c.drawLine(x, 0f, x, gh.toFloat(), line); x += step }
        var y = 0f
        while (y < gh) { c.drawLine(0f, y, w.toFloat(), y, line); y += step }
        // radial ellipse mask: 80% x 50% at (50%, 20%)
        val rx = w * 0.8f
        val ry = h * 0.5f
        val mask = Paint().apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
            shader = RadialGradient(0f, 0f, 1f, Color.BLACK, Color.TRANSPARENT, Shader.TileMode.CLAMP)
        }
        c.save()
        c.translate(w * 0.5f, h * 0.2f)
        c.scale(rx, ry)
        c.drawRect(-3f, -3f, 3f, 3f, mask)
        c.restore()
        grid = bmp
    }

    private fun tri(p: Float): Float {
        val t = if (p < 0.5f) p * 2f else (1f - p) * 2f
        return t * t * (3f - 2f * t) // smoothstep ease-in-out
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        paint.shader = base
        c.drawRect(0f, 0f, w, h, paint)
        paint.shader = null

        val on = 1f - off
        val blueCyan = Color.rgb(60, 190, 255)
        orb(c, w / 2f, dpf(10f), 360f, blueCyan, 0.26f * on + 0.08f * off)
        orb(c, w / 2f, dpf(0f), 340f, Color.rgb(255, 59, 48), 0.22f * off)
        orb(c, w - dpf(10f), h - dpf(10f), 300f, Color.rgb(85, 245, 165), 0.12f * on)

        val s1 = tri(p1)
        val s2 = tri(p2)
        // purple (on) / red (off) orb, drifting
        val d1x = dpf(15f) + dpf(46f) * s1
        val d1y = dpf(435f) - dpf(64f) * s1
        orb(c, d1x, d1y, 270f, Color.rgb(139, 92, 246), 0.24f * on, 1f + 0.15f * s1)
        orb(c, d1x, d1y, 270f, Color.rgb(255, 59, 48), 0.20f * off, 1f + 0.15f * s1)
        // cyan orb, drifting the other way
        val d2x = w - dpf(15f) - dpf(46f) * s2
        val d2y = dpf(645f) + dpf(64f) * s2
        orb(c, d2x, d2y, 250f, Color.rgb(80, 244, 255), 0.26f * on + 0.10f * off, 1f + 0.15f * s2)

        grid?.let { c.drawBitmap(it, 0f, 0f, gridPaint) }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        startDrift()
    }

    override fun onDetachedFromWindow() {
        stopDrift()
        offAnim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) startDrift() else stopDrift()
    }

    private fun startDrift() {
        if (timeAnim != null || !isAttachedToWindow || !ValueAnimator.areAnimatorsEnabled()) return
        timeAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 304000L // 16s and 19s drift cycles line up every 304s
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                val now = SystemClock.uptimeMillis()
                if (now - lastTick < 33L) return@addUpdateListener // ~30 fps is plenty for slow blobs
                lastTick = now
                val t = it.animatedValue as Float
                p1 = (t * 19f) % 1f
                p2 = (t * 16f) % 1f
                invalidate()
            }
            start()
        }
    }

    private fun stopDrift() {
        timeAnim?.cancel()
        timeAnim = null
    }
}
