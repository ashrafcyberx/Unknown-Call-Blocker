package com.ashrafcyberx.unknowncallblocker

import android.animation.ValueAnimator
import android.content.Intent
import android.net.Uri
import android.text.InputType
import android.widget.EditText
import android.widget.FrameLayout
import androidx.appcompat.app.AlertDialog
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import androidx.fragment.app.Fragment
import com.ashrafcyberx.unknowncallblocker.databinding.FragmentHomeBinding

class HomeFragment : Fragment() {
    private var _b: FragmentHomeBinding? = null
    private val b get() = _b!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _b = FragmentHomeBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val main = requireActivity() as MainActivity

        b.btnSettings.setOnClickListener { main.select(R.id.nav_settings) }
        b.cardSaved.setOnClickListener { main.select(R.id.nav_contacts) }
        b.cardLogs.setOnClickListener { main.select(R.id.nav_logs) }
        b.powerButton.setOnClickListener { toggle() }
        b.rowContactsAccess.setOnClickListener { openPermissionsIfNeeded() }
        b.rowRoleAccess.setOnClickListener { openPermissionsIfNeeded() }

        b.choiceBusy.setOnClickListener { chooseStyle(RejectStyle.BUSY) }
        b.choiceSwitchOff.setOnClickListener { chooseStyle(RejectStyle.SWITCH_OFF) }

        playEntrance()
    }

    private fun chooseStyle(style: RejectStyle) {
        val ctx = requireContext()
        val settings = AppSettings(ctx)
        val previous = settings.rejectStyle
        settings.rejectStyle = style
        b.powerButton.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        refreshChoice()
        val main = requireActivity() as MainActivity
        main.showToast(if (style == RejectStyle.BUSY) "Rejected callers will hear BUSY" else "Rejected callers will hear SWITCH OFF")
        // Carrier setup is only offered when it matters.
        if (style == RejectStyle.SWITCH_OFF) showSwitchOffSetup()
        else if (previous == RejectStyle.SWITCH_OFF) showClearForwarding()
    }

    private fun refreshChoice() {
        val binding = _b ?: return
        val style = AppSettings(requireContext()).rejectStyle
        binding.choiceBusy.isSelected = style == RejectStyle.BUSY
        binding.choiceSwitchOff.isSelected = style == RejectStyle.SWITCH_OFF
        binding.textChoiceDesc.text = if (style == RejectStyle.BUSY)
            "Caller hears the busy tone."
        else
            "Caller hears \"switched off / not reachable\". Needs one-time carrier setup (tap SWITCH OFF again)."
    }

    /** Opens the dialer with the code pre-filled; the user must press call themselves. */
    private fun dialCode(code: String) {
        try {
            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(code))))
        } catch (e: Exception) {
            (requireActivity() as MainActivity).showToast("No dialer app found")
        }
    }

    private fun showSwitchOffSetup() {
        val ctx = requireContext()
        val settings = AppSettings(ctx)
        val input = EditText(ctx).apply {
            hint = "Switched-off / unused number"
            inputType = InputType.TYPE_CLASS_PHONE
            setText(settings.forwardNumber)
        }
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = FrameLayout(ctx).apply {
            setPadding(pad, pad / 2, pad, 0)
            addView(input)
        }
        AlertDialog.Builder(ctx)
            .setTitle("One-time setup for SWITCH OFF")
            .setMessage(
                "An app cannot play the \"switched off\" message. Your carrier does, when a rejected call is " +
                    "forwarded to a number that is switched off or not in use.\n\n" +
                    "Enter such a number, then tap Open dialer and press Call. Result depends on your carrier."
            )
            .setView(box)
            .setPositiveButton("Open dialer") { _, _ ->
                val number = input.text.toString().filter { it.isDigit() || it == '+' }
                if (number.length < 6) {
                    (requireActivity() as MainActivity).showToast("Enter a valid number")
                } else {
                    settings.forwardNumber = number
                    dialCode("**67*$number#")
                }
            }
            .setNegativeButton("Later", null)
            .show()
    }

    private fun showClearForwarding() {
        AlertDialog.Builder(requireContext())
            .setTitle("Back to BUSY")
            .setMessage("To hear the normal busy tone again, remove the carrier forwarding you set earlier. Tap Open dialer and press Call.")
            .setPositiveButton("Open dialer") { _, _ -> dialCode("##67#") }
            .setNegativeButton("Skip", null)
            .show()
    }

    /** One staggered slide-up when the app first opens. Not repeated on tab switches. */
    private fun playEntrance() {
        if (entranceShown || !ValueAnimator.areAnimatorsEnabled()) { entranceShown = true; return }
        entranceShown = true
        val content = b.content
        val dy = 24 * resources.displayMetrics.density
        for (i in 1 until content.childCount) {
            val v = content.getChildAt(i)
            v.alpha = 0f
            v.translationY = dy
            v.animate().alpha(1f).translationY(0f)
                .setStartDelay(70L * i).setDuration(400)
                .setInterpolator(DecelerateInterpolator()).start()
        }
    }

    override fun onResume() {
        super.onResume()
        refresh(animate = false)
    }

    private fun openPermissionsIfNeeded() {
        val ctx = requireContext()
        if (!Setup.isComplete(ctx)) startActivity(Intent(ctx, PermissionsActivity::class.java))
    }

    private fun toggle() {
        val ctx = requireContext()
        if (!Setup.isComplete(ctx)) {
            startActivity(Intent(ctx, PermissionsActivity::class.java))
            return
        }
        b.powerButton.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        val settings = AppSettings(ctx)
        settings.blockingEnabled = !settings.blockingEnabled
        refresh(animate = true)

        val main = requireActivity() as MainActivity
        main.refreshProtection(animate = true)
        main.showToast(if (settings.blockingEnabled) "Call blocking turned on" else "Call blocking turned off")
    }

    private fun replay(v: View) {
        v.animate().cancel()
        v.alpha = 0f
        v.translationY = 6 * resources.displayMetrics.density
        v.animate().alpha(1f).translationY(0f).setDuration(500).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun refresh(animate: Boolean) {
        val binding = _b ?: return
        val ctx = requireContext()
        val settings = AppSettings(ctx)
        val complete = Setup.isComplete(ctx)

        val on: Boolean
        val color: Int
        val power: String
        val status: String
        val desc: String
        val hint: String
        when {
            !complete -> {
                on = false; color = ctx.getColor(R.color.warning); power = "SETUP"
                status = "Setup Required"
                desc = "Allow contacts access and choose this app as your call screening app."
                hint = "Tap the button to finish setup"
            }
            !settings.blockingEnabled -> {
                on = false; color = ctx.getColor(R.color.danger_text); power = "OFF"
                status = "Protection Off"
                desc = "Blocking is paused. Unknown numbers can call you right now."
                hint = "Tap the button to turn on"
            }
            else -> {
                on = true; color = ctx.getColor(R.color.accent); power = "ON"
                status = "Protection Active"
                desc = "Unknown numbers are rejected automatically. Only your saved contacts can reach you."
                hint = "Tap the button to turn off"
            }
        }

        val changed = binding.textState.text.toString() != status
        binding.powerButton.setState(on, power, animate)
        binding.powerButton.contentDescription = "Call blocking $power"

        binding.statusPill.background = GlassUi.tinted(ctx, color, 30f, fill = 0.04f, line = 0.17f)
        binding.statusDot.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
        }
        binding.textState.setTextColor(color)
        binding.textState.text = status
        binding.textStateDesc.text = desc
        binding.textHint.text = hint
        if (animate && changed) {
            replay(binding.statusPill)
            replay(binding.textStateDesc)
            replay(binding.textHint)
        }

        refreshChoice()
        binding.choiceCard.alpha = if (on) 1f else 0.5f

        val (total, blocked) = CallLogStore(ctx).todayCounts()
        binding.textTotal.text = total.toString()
        binding.textBlockedToday.text = blocked.toString()
        binding.textAllowedToday.text = (total - blocked).coerceAtLeast(0).toString()

        val granted = ctx.getColor(R.color.accent)
        val missing = ctx.getColor(R.color.warning)
        val hasContacts = Setup.hasContacts(ctx)
        val hasRole = Setup.hasRole(ctx)
        binding.tagContacts.text = if (hasContacts) "Granted" else "Not set"
        GlassUi.styleTag(binding.tagContacts, if (hasContacts) granted else missing)
        binding.tagRole.text = if (hasRole) "Selected" else "Not set"
        GlassUi.styleTag(binding.tagRole, if (hasRole) granted else missing)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _b = null
    }

    private companion object {
        var entranceShown = false
    }
}
