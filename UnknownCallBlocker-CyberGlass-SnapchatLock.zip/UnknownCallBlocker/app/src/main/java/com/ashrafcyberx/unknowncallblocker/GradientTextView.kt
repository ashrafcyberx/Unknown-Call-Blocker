package com.ashrafcyberx.unknowncallblocker

import android.content.Context
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatTextView

/** Text filled with a green -> mint horizontal gradient (the "Blocker" word in the title). */
class GradientTextView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : AppCompatTextView(context, attrs, defStyleAttr) {

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)
        val w = (right - left).toFloat()
        if (w > 0f) {
            paint.shader = LinearGradient(
                0f, 0f, w, 0f,
                Color.rgb(85, 245, 165), Color.rgb(157, 255, 208), Shader.TileMode.CLAMP
            )
        }
    }
}
