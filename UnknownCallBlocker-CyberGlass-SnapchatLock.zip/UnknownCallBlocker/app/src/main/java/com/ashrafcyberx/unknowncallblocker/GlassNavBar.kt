package com.ashrafcyberx.unknowncallblocker

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat

/** Floating glass tab bar with a sliding selection pill. */
class GlassNavBar @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : GlassCard(context, attrs, defStyleAttr) {

    private class Item(val id: Int, val icon: ImageView, val label: TextView, val root: LinearLayout)

    var onSelected: ((Int) -> Unit)? = null
    var selectedId: Int = R.id.nav_home
        private set

    private val items = ArrayList<Item>()
    private val pad = dpf(6f)
    private var pos = 0f // pill position in item units
    private var posAnim: ValueAnimator? = null
    private val pillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pillHi = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dpf(1f) }
    private val pillRect = RectF()
    private val selColor = Color.rgb(117, 244, 255)
    private val idleColor = Color.rgb(130, 149, 169)

    init {
        val padPx = pad.toInt()
        setPadding(padPx, padPx, padPx, padPx)
        val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        addView(row, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        val defs = listOf(
            Triple(R.id.nav_home, R.drawable.ic_home, "Home"),
            Triple(R.id.nav_contacts, R.drawable.ic_people, "Contacts"),
            Triple(R.id.nav_logs, R.drawable.ic_history, "Logs"),
            Triple(R.id.nav_settings, R.drawable.ic_settings, "Settings")
        )
        for ((id, iconRes, title) in defs) {
            val cell = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(0, dpf(8f).toInt(), 0, dpf(6f).toInt())
                isClickable = true
                isFocusable = true
                contentDescription = title
            }
            val iv = ImageView(context).apply {
                setImageDrawable(ContextCompat.getDrawable(context, iconRes))
                importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
            }
            cell.addView(iv, LinearLayout.LayoutParams(dpf(23f).toInt(), dpf(23f).toInt()))
            val tv = TextView(context).apply {
                this.text = title
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
                typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER
                importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
            }
            val tvLp = LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)
            tvLp.topMargin = dpf(4f).toInt()
            cell.addView(tv, tvLp)
            row.addView(cell, LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
            val item = Item(id, iv, tv, cell)
            items.add(item)
            cell.setOnClickListener { select(id, true) }
            cell.setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(90).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
                }
                false
            }
        }
        applyColors()
    }

    private fun indexOf(id: Int): Int = items.indexOfFirst { it.id == id }.coerceAtLeast(0)

    /** Select a tab. When `notify` is true the listener fires (only if it changed). */
    fun select(id: Int, notify: Boolean = true) {
        if (id == selectedId && notify) return
        selectedId = id
        applyColors()
        val target = indexOf(id).toFloat()
        posAnim?.cancel()
        if (ValueAnimator.areAnimatorsEnabled() && isAttachedToWindow && width > 0) {
            posAnim = ValueAnimator.ofFloat(pos, target).apply {
                duration = 340L
                interpolator = OvershootInterpolator(0.8f)
                addUpdateListener { pos = it.animatedValue as Float; invalidate() }
                start()
            }
        } else {
            pos = target
            invalidate()
        }
        if (notify) onSelected?.invoke(id)
    }

    /** Restore state after rotation without animating or notifying. */
    fun restore(id: Int) {
        selectedId = id
        pos = indexOf(id).toFloat()
        applyColors()
        invalidate()
    }

    private fun applyColors() {
        for (item in items) {
            val sel = item.id == selectedId
            val c = if (sel) selColor else idleColor
            item.icon.setColorFilter(c, android.graphics.PorterDuff.Mode.SRC_IN)
            item.label.setTextColor(c)
            item.icon.animate().scaleX(if (sel) 1.08f else 1f).scaleY(if (sel) 1.08f else 1f).setDuration(250).start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (items.isEmpty() || width == 0) return
        val inner = width - 2f * pad
        val cell = inner / items.size
        val left = pad + pos * cell
        pillRect.set(left, pad, left + cell, height - pad)
        pillPaint.shader = cssGradient(
            pillRect.width(), pillRect.height(), 145f,
            intArrayOf(Color.argb(38, 80, 244, 255), Color.argb(20, 91, 140, 255)), null
        )
        canvas.save()
        canvas.translate(pillRect.left, pillRect.top)
        val r = dpf(24f)
        val local = RectF(0f, 0f, pillRect.width(), pillRect.height())
        canvas.drawRoundRect(local, r, r, pillPaint)
        pillHi.color = Color.argb(48, 255, 255, 255)
        canvas.drawLine(r, 0.5f, local.right - r, 0.5f, pillHi)
        canvas.restore()
    }
}
