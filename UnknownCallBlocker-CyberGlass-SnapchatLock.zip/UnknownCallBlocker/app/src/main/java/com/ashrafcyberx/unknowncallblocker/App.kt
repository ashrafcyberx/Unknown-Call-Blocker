package com.ashrafcyberx.unknowncallblocker

import android.app.Activity
import android.app.Application
import android.content.Intent
import android.os.Bundle

/** Sends every screen to the "Snapchat Detected" page while Snapchat is installed. */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityResumed(activity: Activity) {
                if (activity is SnapchatBlockActivity) return
                if (SnapchatGuard.isInstalled(activity)) {
                    activity.startActivity(
                        Intent(activity, SnapchatBlockActivity::class.java)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                    )
                    activity.finish()
                }
            }
            override fun onActivityCreated(a: Activity, s: Bundle?) {}
            override fun onActivityStarted(a: Activity) {}
            override fun onActivityPaused(a: Activity) {}
            override fun onActivityStopped(a: Activity) {}
            override fun onActivitySaveInstanceState(a: Activity, s: Bundle) {}
            override fun onActivityDestroyed(a: Activity) {}
        })
    }
}
