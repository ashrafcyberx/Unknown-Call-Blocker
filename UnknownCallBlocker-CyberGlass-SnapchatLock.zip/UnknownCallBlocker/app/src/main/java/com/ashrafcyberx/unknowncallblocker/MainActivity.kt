package com.ashrafcyberx.unknowncallblocker

import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction
import com.ashrafcyberx.unknowncallblocker.databinding.ActivityMainBinding

/** Hosts the four tabs (Home, Contacts, Logs, Settings) behind the floating glass tab bar. */
class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val toastHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val hideToast = Runnable { animateToastOut() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val controller = WindowCompat.getInsetsController(window, binding.root)
        controller.isAppearanceLightStatusBars = false
        controller.isAppearanceLightNavigationBars = false
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { _, insets ->
            applyInsets(insets)
            insets
        }

        binding.navBar.onSelected = { id -> showTab(id) }
        if (savedInstanceState == null) {
            binding.navBar.restore(R.id.nav_home)
            showTab(R.id.nav_home)
        } else {
            binding.navBar.restore(savedInstanceState.getInt(KEY_TAB, R.id.nav_home))
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(KEY_TAB, binding.navBar.selectedId)
    }

    override fun onResume() {
        super.onResume()
        refreshProtection(animate = false)
    }

    override fun onDestroy() {
        toastHandler.removeCallbacks(hideToast)
        super.onDestroy()
    }

    private fun showTab(itemId: Int) {
        val fragment: Fragment = when (itemId) {
            R.id.nav_contacts -> ContactsFragment()
            R.id.nav_logs -> LogsFragment()
            R.id.nav_settings -> SettingsFragment()
            else -> HomeFragment()
        }
        supportFragmentManager.beginTransaction()
            .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
            .replace(R.id.container, fragment)
            .commit()
    }

    /** Switch tab from inside a fragment. */
    fun select(itemId: Int) {
        binding.navBar.select(itemId, true)
    }

    /** Recolours the backdrop glow (cyan/green when protected, red when off or not set up). */
    fun refreshProtection(animate: Boolean) {
        val on = AppSettings(this).blockingEnabled && Setup.isComplete(this)
        binding.glow.setProtectionOn(on, animate)
    }

    /** Glass toast that drops in from the top, like the HTML design. */
    fun showToast(message: String) {
        val toast = binding.toast
        binding.toastText.text = message
        toastHandler.removeCallbacks(hideToast)
        toast.animate().cancel()
        toast.visibility = View.VISIBLE
        toast.alpha = 0f
        toast.translationY = -dpf(16f)
        toast.animate().alpha(1f).translationY(0f).setDuration(350L)
            .setInterpolator(android.view.animation.OvershootInterpolator(1.1f)).start()
        toastHandler.postDelayed(hideToast, 1700L)
    }

    private fun animateToastOut() {
        val toast = binding.toast
        toast.animate().alpha(0f).translationY(-dpf(16f)).setDuration(260L)
            .withEndAction { toast.visibility = View.INVISIBLE }.start()
    }

    private fun applyInsets(insets: WindowInsetsCompat) {
        val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
        val ime = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom
        @Suppress("DEPRECATION")
        val legacy = if (Build.VERSION.SDK_INT < 30) insets.systemWindowInsetBottom else 0
        val total = maxOf(bars.bottom, ime, legacy)
        val keyboard = total > bars.bottom + dpf(80f)

        binding.container.setPadding(0, bars.top, 0, if (keyboard) total else bars.bottom)

        binding.navBar.visibility = if (keyboard) View.GONE else View.VISIBLE
        val navLp = binding.navBar.layoutParams as FrameLayout.LayoutParams
        navLp.bottomMargin = bars.bottom + dpf(12f).toInt()
        binding.navBar.layoutParams = navLp

        val toastLp = binding.toast.layoutParams as FrameLayout.LayoutParams
        toastLp.topMargin = bars.top + dpf(14f).toInt()
        binding.toast.layoutParams = toastLp
    }

    private companion object {
        const val KEY_TAB = "selected_tab"
    }
}
