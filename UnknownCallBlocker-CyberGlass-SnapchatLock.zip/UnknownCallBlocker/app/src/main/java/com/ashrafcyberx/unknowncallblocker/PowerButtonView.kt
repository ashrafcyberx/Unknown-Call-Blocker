package com.ashrafcyberx.unknowncallblocker

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils

/**
 * The big glowing power button: breathing halo, spinning gradient ring,
 * glass core, icon and ON/OFF label. Draws everything itself.
 * Layout size should be square; artwork is designed on a 300dp canvas.
 */
class PowerButtonView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var off = 0f          // 0 = on look, 1 = off look
    private var label = "ON"
    private var swap = 1f         // label swap-in progress
    private var spin = 0f         // degrees
    private var breathe = 0f      // 0..1
    private var press = 0f
    private var ripple = -1f      // <0: none
    private var rippleColor = Color.rgb(80, 244, 255)
    private var isOnLook = true

    private var offAnim: ValueAnimator? = null
    private var swapAnim: ValueAnimator? = null
    private var pressAnim: ValueAnimator? = null
    private var rippleAnim: ValueAnimator? = null
    private var spinAnim: ValueAnimator? = null
    private var breatheAnim: ValueAnimator? = null

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        textAlign = Paint.Align.CENTER
        letterSpacing = 0.13f
    }
    private val icon: Drawable? = ContextCompat.getDrawable(context, R.drawable.ic_power)?.mutate()

    private var haloOn: RadialGradient? = null
    private var haloOff: RadialGradient? = null
    private var sweepOn: SweepGradient? = null
    private var sweepOff: SweepGradient? = null
    private var coreOn: RadialGradient? = null
    private var coreOff: RadialGradient? = null
    private var shadowShader: RadialGradient? = null
    private var innerGlow: RadialGradient? = null
    private var edgeShader: LinearGradient? = null
    private var shineShader: LinearGradient? = null
    private val corePath = Path()
    private val shineRect = RectF()

    private val colMint = Color.rgb(157, 255, 208)
    private val colGray = Color.rgb(124, 135, 148)
    private val colLabelOn = Color.rgb(233, 255, 245)
    private val colLabelOff = Color.rgb(154, 164, 176)

    init {
        isClickable = true
        isFocusable = true
    }

    /** Set the visual state. `on` = glowing cyan/green, otherwise dark red look. */
    fun setState(on: Boolean, newLabel: String, animate: Boolean) {
        val stateChanged = on != isOnLook
        val labelChanged = newLabel != label
        isOnLook = on
        label = newLabel
        val target = if (on) 0f else 1f
        offAnim?.cancel()
        if (!animate || !isAttachedToWindow) {
            off = target
            swap = 1f
            invalidate()
            return
        }
        offAnim = ValueAnimator.ofFloat(off, target).apply {
            duration = 600L
            addUpdateListener { off = it.animatedValue as Float; invalidate() }
            start()
        }
        if (labelChanged) {
            swapAnim?.cancel()
            swapAnim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 500L
                interpolator = DecelerateInterpolator()
                addUpdateListener { swap = it.animatedValue as Float; invalidate() }
                start()
            }
        }
        if (stateChanged) playRipple(if (on) Color.rgb(80, 244, 255) else Color.rgb(255, 59, 48))
    }

    private fun playRipple(color: Int) {
        rippleColor = color
        rippleAnim?.cancel()
        rippleAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 900L
            interpolator = DecelerateInterpolator()
            addUpdateListener { ripple = it.animatedValue as Float; invalidate() }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    ripple = -1f
                    invalidate()
                }
            })
            start()
        }
    }

    override fun setPressed(pressed: Boolean) {
        super.setPressed(pressed)
        pressAnim?.cancel()
        pressAnim = ValueAnimator.ofFloat(press, if (pressed) 1f else 0f).apply {
            duration = 160L
            interpolator = if (pressed) AccelerateDecelerateInterpolator() else OvershootInterpolator(2f)
            addUpdateListener { press = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val cx = w / 2f
        val cy = h / 2f
        val d = dpf(1f)

        // halo (unit radius, scaled when drawing)
        haloOn = RadialGradient(
            0f, 0f, 1f,
            intArrayOf(Color.argb(85, 80, 244, 255), Color.argb(38, 85, 245, 165), Color.argb(0, 85, 245, 165), Color.argb(0, 85, 245, 165)),
            floatArrayOf(0f, 0.58f, 0.75f, 1f), Shader.TileMode.CLAMP
        )
        haloOff = RadialGradient(
            0f, 0f, 1f,
            intArrayOf(Color.argb(51, 255, 59, 48), Color.argb(0, 255, 59, 48), Color.argb(0, 255, 59, 48)),
            floatArrayOf(0f, 0.72f, 1f), Shader.TileMode.CLAMP
        )
        sweepOn = SweepGradient(
            cx, cy,
            intArrayOf(
                Color.rgb(91, 140, 255), Color.rgb(80, 244, 255), Color.rgb(112, 255, 192),
                Color.rgb(80, 244, 255), Color.rgb(91, 140, 255)
            ),
            floatArrayOf(0f, 0.25f, 0.5f, 0.75f, 1f)
        )
        sweepOff = SweepGradient(
            cx, cy,
            intArrayOf(
                Color.rgb(59, 66, 77), Color.rgb(26, 32, 40), Color.rgb(59, 66, 77),
                Color.rgb(26, 32, 40), Color.rgb(59, 66, 77)
            ),
            floatArrayOf(0f, 0.25f, 0.5f, 0.75f, 1f)
        )

        val rc = 89f * d
        val box = rc * 2f
        corePath.reset()
        corePath.addCircle(cx, cy, rc, Path.Direction.CW)
        // radial-gradient(circle at 35% 15%, ...) farthest-corner radius
        val gx = cx - rc + 0.35f * box
        val gy = cy - rc + 0.15f * box
        val gr = Math.hypot((0.65f * box).toDouble(), (0.85f * box).toDouble()).toFloat()
        coreOn = RadialGradient(
            gx, gy, gr,
            intArrayOf(Color.rgb(24, 59, 59), Color.rgb(8, 19, 27), Color.rgb(6, 10, 16)),
            floatArrayOf(0f, 0.58f, 1f), Shader.TileMode.CLAMP
        )
        coreOff = RadialGradient(
            gx, gy, gr,
            intArrayOf(Color.rgb(41, 33, 42), Color.rgb(17, 16, 24), Color.rgb(8, 9, 14)),
            floatArrayOf(0f, 0.58f, 1f), Shader.TileMode.CLAMP
        )
        shadowShader = RadialGradient(
            cx, cy + 16f * d, rc + 22f * d,
            intArrayOf(Color.argb(170, 0, 0, 0), Color.argb(150, 0, 0, 0), Color.argb(0, 0, 0, 0)),
            floatArrayOf(0f, 0.72f, 1f), Shader.TileMode.CLAMP
        )
        innerGlow = RadialGradient(
            cx, cy + rc, rc * 0.95f,
            intArrayOf(Color.argb(30, 80, 244, 255), Color.argb(0, 80, 244, 255)),
            null, Shader.TileMode.CLAMP
        )
        edgeShader = LinearGradient(
            0f, cy - rc, 0f, cy + rc,
            intArrayOf(Color.argb(60, 255, 255, 255), Color.argb(0, 255, 255, 255), Color.argb(0, 255, 255, 255)),
            floatArrayOf(0f, 0.4f, 1f), Shader.TileMode.CLAMP
        )
        shineRect.set(cx - rc + 0.15f * box, cy - rc + 0.07f * box, cx + rc - 0.15f * box, cy - rc + 0.49f * box)
        shineShader = LinearGradient(
            0f, shineRect.top, 0f, shineRect.bottom,
            Color.argb(61, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val d = dpf(1f)
        val sc = (minOf(w, h) / (300f * d)).coerceAtMost(1.2f)
        val on = 1f - off

        c.save()
        c.scale(sc, sc, cx, cy)

        // ---- halo ----
        val bScale = 1f + 0.07f * breathe
        val bAlpha = 1f - 0.25f * breathe
        paint.shader = haloOn
        paint.alpha = (255f * on * bAlpha).toInt().coerceIn(0, 255)
        if (paint.alpha > 0) {
            c.save(); c.translate(cx, cy); c.scale(148f * d * bScale, 148f * d * bScale)
            c.drawCircle(0f, 0f, 1f, paint); c.restore()
        }
        paint.shader = haloOff
        paint.alpha = (255f * off).toInt().coerceIn(0, 255)
        if (paint.alpha > 0) {
            c.save(); c.translate(cx, cy); c.scale(148f * d, 148f * d)
            c.drawCircle(0f, 0f, 1f, paint); c.restore()
        }
        paint.shader = null
        paint.alpha = 255

        // ---- outer thin ring ----
        ringPaint.shader = null
        ringPaint.strokeWidth = 1.5f * d
        ringPaint.color = ColorUtils.blendARGB(Color.argb(43, 80, 244, 255), Color.argb(28, 255, 255, 255), off)
        c.drawCircle(cx, cy, 114f * d, ringPaint)

        // ---- gradient ring (spins when on) ----
        val ringR = 102f * d
        if (on > 0.01f) {
            ringPaint.shader = sweepOn
            c.save()
            c.rotate(spin, cx, cy)
            ringPaint.strokeWidth = 22f * d
            ringPaint.alpha = (255f * 0.06f * on).toInt()
            c.drawCircle(cx, cy, ringR - 4f * d, ringPaint)
            ringPaint.strokeWidth = 14f * d
            ringPaint.alpha = (255f * 0.12f * on).toInt()
            c.drawCircle(cx, cy, ringR - 4f * d, ringPaint)
            ringPaint.strokeWidth = 8f * d
            ringPaint.alpha = (255f * on).toInt()
            c.drawCircle(cx, cy, ringR - 4f * d, ringPaint)
            c.restore()
        }
        if (off > 0.01f) {
            ringPaint.shader = sweepOff
            ringPaint.strokeWidth = 8f * d
            ringPaint.alpha = (255f * off).toInt()
            c.drawCircle(cx, cy, ringR - 4f * d, ringPaint)
        }
        ringPaint.shader = null
        ringPaint.alpha = 255

        // ---- core (pressed state scales it down) ----
        val ps = 1f - 0.05f * press
        c.save()
        c.scale(ps, ps, cx, cy)

        paint.shader = shadowShader
        c.drawCircle(cx, cy + 16f * d, 89f * d + 22f * d, paint)

        paint.shader = coreOn
        paint.alpha = 255
        c.drawPath(corePath, paint)
        if (off > 0.01f) {
            paint.shader = coreOff
            paint.alpha = (255f * off).toInt()
            c.drawPath(corePath, paint)
        }
        paint.alpha = 255

        c.save()
        c.clipPath(corePath)
        paint.shader = innerGlow
        c.drawCircle(cx, cy + 89f * d, 89f * d * 0.95f, paint)
        c.restore()

        paint.shader = null
        ringPaint.shader = edgeShader
        ringPaint.strokeWidth = 1.2f * d
        c.drawCircle(cx, cy, 89f * d - 0.6f * d, ringPaint)
        ringPaint.shader = null

        paint.shader = shineShader
        c.drawOval(shineRect, paint)
        paint.shader = null

        // ---- icon + label ----
        val iconColor = ColorUtils.blendARGB(colMint, colGray, off)
        val iconSize = 43f * d
        val iconCy = cy - 15f * d
        if (on > 0.01f) {
            paint.shader = RadialGradient(
                cx, iconCy, iconSize * 0.75f,
                Color.argb((70f * on).toInt(), 85, 245, 165), Color.argb(0, 85, 245, 165), Shader.TileMode.CLAMP
            )
            c.drawCircle(cx, iconCy, iconSize * 0.75f, paint)
            paint.shader = null
        }
        icon?.let {
            it.setBounds(
                (cx - iconSize / 2f).toInt(), (iconCy - iconSize / 2f).toInt(),
                (cx + iconSize / 2f).toInt(), (iconCy + iconSize / 2f).toInt()
            )
            it.setTint(iconColor)
            it.draw(c)
        }

        textPaint.textSize = 28f * d
        textPaint.color = ColorUtils.blendARGB(colLabelOn, colLabelOff, off)
        textPaint.alpha = (255f * swap).toInt().coerceIn(0, 255)
        val fm = textPaint.fontMetrics
        val labelCy = cy + 24f * d + (1f - swap) * 6f * d
        val baseline = labelCy - (fm.ascent + fm.descent) / 2f
        val x = cx + textPaint.letterSpacing * textPaint.textSize / 2f
        c.drawText(label, x, baseline, textPaint)
        c.restore()

        // ---- ripple ----
        if (ripple in 0f..1f) {
            ringPaint.shader = null
            ringPaint.strokeWidth = 2f * d
            ringPaint.color = rippleColor
            ringPaint.alpha = (255f * 0.8f * (1f - ripple)).toInt().coerceIn(0, 255)
            c.drawCircle(cx, cy, ringR * (1f + 0.55f * ripple), ringPaint)
            ringPaint.alpha = 255
        }
        c.restore()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        startLoops()
    }

    override fun onDetachedFromWindow() {
        stopLoops()
        offAnim?.cancel(); swapAnim?.cancel(); pressAnim?.cancel(); rippleAnim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) startLoops() else stopLoops()
    }

    private fun startLoops() {
        if (spinAnim != null || !isAttachedToWindow || !ValueAnimator.areAnimatorsEnabled()) return
        spinAnim = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 7000L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { spin = it.animatedValue as Float; invalidate() }
            start()
        }
        breatheAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2250L
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { breathe = it.animatedValue as Float }
            start()
        }
    }

    private fun stopLoops() {
        spinAnim?.cancel(); spinAnim = null
        breatheAnim?.cancel(); breatheAnim = null
    }
}
