package com.ashrafcyberx.unknowncallblocker

import android.content.res.ColorStateList
import android.os.Bundle
import android.text.format.DateUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ashrafcyberx.unknowncallblocker.databinding.FragmentLogsBinding
import com.ashrafcyberx.unknowncallblocker.databinding.ItemLogBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LogsFragment : Fragment() {
    private var _b: FragmentLogsBinding? = null
    private val b get() = _b!!
    private var filter = 0 // 0 = all, 1 = accepted, 2 = blocked
    private val adapter = LogsAdapter()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _b = FragmentLogsBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        b.list.layoutManager = LinearLayoutManager(requireContext())
        b.list.adapter = adapter
        b.btnClear.setOnClickListener {
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Clear call logs?")
                .setMessage("This removes the list kept by this app. Your phone's call history is not touched.")
                .setPositiveButton("Clear") { _, _ ->
                    CallLogStore(requireContext()).clear()
                    reload()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        b.chipAll.setOnClickListener { setFilter(0) }
        b.chipAccepted.setOnClickListener { setFilter(1) }
        b.chipBlocked.setOnClickListener { setFilter(2) }
        setFilter(0)
    }

    override fun onResume() {
        super.onResume()
        reload()
    }

    private fun setFilter(value: Int) {
        filter = value
        b.chipAll.isSelected = value == 0
        b.chipAccepted.isSelected = value == 1
        b.chipBlocked.isSelected = value == 2
        reload()
    }

    private fun reload() {
        val binding = _b ?: return
        val entries = CallLogStore(requireContext()).all().filter {
            when (filter) {
                1 -> !it.blocked
                2 -> it.blocked
                else -> true
            }
        }
        adapter.submit(entries)
        binding.textEmpty.visibility = if (entries.isEmpty()) View.VISIBLE else View.GONE
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _b = null
    }
}

class LogsAdapter : RecyclerView.Adapter<LogsAdapter.VH>() {
    private var items: List<LogEntry> = emptyList()

    fun submit(list: List<LogEntry>) {
        items = list
        notifyDataSetChanged()
    }

    class VH(val b: ItemLogBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemLogBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val e = items[position]
        val ctx = holder.itemView.context
        val green = ctx.getColor(R.color.accent)
        val red = ctx.getColor(R.color.danger)
        val redText = ctx.getColor(R.color.danger_text)
        val time = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(e.time))

        holder.b.textTitle.text = when {
            e.name != null -> e.name
            e.number.isEmpty() -> "Private Number"
            else -> "Unknown Number"
        }
        holder.b.textNumber.text = if (e.number.isEmpty()) "Hidden caller ID" else e.number

        val tile = if (e.blocked) red else green
        holder.b.icon.background = GlassUi.tinted(ctx, tile, 13f)
        holder.b.icon.imageTintList = ColorStateList.valueOf(tile)
        holder.b.icon.setImageResource(if (e.blocked) R.drawable.ic_block else R.drawable.ic_phone)
        holder.b.textStatus.setTextColor(if (e.blocked) redText else green)
        holder.b.textStatus.text = (if (e.blocked) "Blocked" else "Accepted") + " \u2022 " + time
        holder.b.textRight.text = dayLabel(e.time)
        holder.b.divider.visibility = if (position == 0) View.GONE else View.VISIBLE
    }

    private fun dayLabel(time: Long): String = when {
        DateUtils.isToday(time) -> "Today"
        DateUtils.isToday(time + DateUtils.DAY_IN_MILLIS) -> "Yesterday"
        else -> SimpleDateFormat("dd MMM", Locale.getDefault()).format(Date(time))
    }
}
