package com.ashrafcyberx.unknowncallblocker

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button

/** Shown instead of the app while Snapchat is installed. */
class SnapchatBlockActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_snapchat_block)

        findViewById<Button>(R.id.btnUninstall).setOnClickListener {
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${SnapchatGuard.PACKAGE}")))
        }
        findViewById<Button>(R.id.btnCheckAgain).setOnClickListener { continueIfRemoved() }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = finishAffinity()
        })
    }

    override fun onResume() {
        super.onResume()
        continueIfRemoved()
    }

    private fun continueIfRemoved() {
        if (!SnapchatGuard.isInstalled(this)) {
            startActivity(
                Intent(this, SplashActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            )
            finish()
        }
    }
}
