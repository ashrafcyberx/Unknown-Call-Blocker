package com.ashrafcyberx.unknowncallblocker

import android.content.Context
import android.content.pm.PackageManager

/** Detects whether Snapchat is installed on this phone. */
object SnapchatGuard {
    const val PACKAGE = "com.snapchat.android"

    fun isInstalled(ctx: Context): Boolean = try {
        @Suppress("DEPRECATION")
        ctx.packageManager.getPackageInfo(PACKAGE, 0)
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    } catch (e: Exception) {
        false
    }
}
