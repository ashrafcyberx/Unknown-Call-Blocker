package com.ashrafcyberx.unknowncallblocker

import android.content.Context

/** Version name from the installed package (e.g. "1.0.0"). */
fun Context.appVersion(): String =
    try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: "1.0.0"
    } catch (e: Exception) {
        "1.0.0"
    }
