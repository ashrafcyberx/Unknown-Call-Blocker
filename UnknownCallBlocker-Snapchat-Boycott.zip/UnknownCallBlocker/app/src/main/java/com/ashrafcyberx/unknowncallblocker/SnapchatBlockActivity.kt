package com.ashrafcyberx.unknowncallblocker

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

/**
 * Hard lock: shown instead of every screen while Snapchat is installed.
 * It cannot be dismissed; it closes only after Snapchat has been uninstalled.
 */
class SnapchatBlockActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_snapchat_block)

        findViewById<ImageView>(R.id.imgBoycott).apply {
            outlineProvider = ViewOutlineProvider.BACKGROUND
            clipToOutline = true
        }

        findViewById<Button>(R.id.btnUninstall).setOnClickListener {
            try {
                startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${SnapchatGuard.PACKAGE}")))
            } catch (e: Exception) {
                Toast.makeText(this, "Open Settings > Apps > Snapchat > Uninstall", Toast.LENGTH_LONG).show()
            }
        }
        findViewById<Button>(R.id.btnCheckAgain).setOnClickListener {
            if (SnapchatGuard.isInstalled(this)) {
                Toast.makeText(this, "Snapchat is still installed", Toast.LENGTH_SHORT).show()
            } else {
                continueIfRemoved()
            }
        }
        findViewById<View>(R.id.btnExit).setOnClickListener { finishAffinity() }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = finishAffinity()
        })

        // Pop-up entrance.
        findViewById<View>(R.id.popupCard).apply {
            alpha = 0f
            scaleX = 0.9f
            scaleY = 0.9f
            animate().alpha(1f).scaleX(1f).scaleY(1f)
                .setDuration(320).setInterpolator(DecelerateInterpolator()).start()
        }
    }

    override fun onResume() {
        super.onResume()
        continueIfRemoved()
    }

    private fun continueIfRemoved() {
        if (!SnapchatGuard.isInstalled(this)) {
            startActivity(
                Intent(this, SplashActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            )
            finish()
        }
    }
}
