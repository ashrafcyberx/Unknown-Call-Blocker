package com.ashrafcyberx.unknowncallblocker

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

/** Detects whether Snapchat is installed. Uses several methods because phones differ. */
object SnapchatGuard {
    const val PACKAGE = "com.snapchat.android"

    fun isInstalled(ctx: Context): Boolean {
        val pm = ctx.packageManager

        // 1. Exact package name.
        try {
            @Suppress("DEPRECATION")
            pm.getPackageInfo(PACKAGE, 0)
            return true
        } catch (e: PackageManager.NameNotFoundException) {
        } catch (e: Exception) {
        }

        // 2. Launcher intent for the package.
        try {
            if (pm.getLaunchIntentForPackage(PACKAGE) != null) return true
        } catch (e: Exception) {
        }

        // 3. Any installed package with "snapchat" in its name (clones, variants).
        try {
            @Suppress("DEPRECATION")
            val apps = pm.getInstalledApplications(0)
            if (apps.any { it.packageName.contains("snapchat", ignoreCase = true) }) return true
        } catch (e: Exception) {
        }

        // 4. Any launcher app whose visible name is "Snapchat".
        try {
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            @Suppress("DEPRECATION")
            val list = pm.queryIntentActivities(main, 0)
            if (list.any { it.loadLabel(pm).toString().contains("snapchat", ignoreCase = true) }) return true
        } catch (e: Exception) {
        }
        return false
    }
}
