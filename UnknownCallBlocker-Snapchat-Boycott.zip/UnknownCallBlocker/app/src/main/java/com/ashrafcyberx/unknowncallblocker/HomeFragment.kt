package com.ashrafcyberx.unknowncallblocker

import android.animation.ValueAnimator
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import androidx.fragment.app.Fragment
import com.ashrafcyberx.unknowncallblocker.databinding.FragmentHomeBinding

class HomeFragment : Fragment() {
    private var _b: FragmentHomeBinding? = null
    private val b get() = _b!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _b = FragmentHomeBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val main = requireActivity() as MainActivity

        b.btnSettings.setOnClickListener { main.select(R.id.nav_settings) }
        b.cardSaved.setOnClickListener { main.select(R.id.nav_contacts) }
        b.cardLogs.setOnClickListener { main.select(R.id.nav_logs) }
        b.powerButton.setOnClickListener { toggle() }
        b.rowContactsAccess.setOnClickListener { openPermissionsIfNeeded() }
        b.rowRoleAccess.setOnClickListener { openPermissionsIfNeeded() }

        playEntrance()
    }

    /** One staggered slide-up when the app first opens. Not repeated on tab switches. */
    private fun playEntrance() {
        if (entranceShown || !ValueAnimator.areAnimatorsEnabled()) { entranceShown = true; return }
        entranceShown = true
        val content = b.content
        val dy = 24 * resources.displayMetrics.density
        for (i in 1 until content.childCount) {
            val v = content.getChildAt(i)
            v.alpha = 0f
            v.translationY = dy
            v.animate().alpha(1f).translationY(0f)
                .setStartDelay(70L * i).setDuration(400)
                .setInterpolator(DecelerateInterpolator()).start()
        }
    }

    override fun onResume() {
        super.onResume()
        refresh(animate = false)
    }

    private fun openPermissionsIfNeeded() {
        val ctx = requireContext()
        if (!Setup.isComplete(ctx)) startActivity(Intent(ctx, PermissionsActivity::class.java))
    }

    private fun toggle() {
        val ctx = requireContext()
        if (!Setup.isComplete(ctx)) {
            startActivity(Intent(ctx, PermissionsActivity::class.java))
            return
        }
        b.powerButton.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        val settings = AppSettings(ctx)
        settings.blockingEnabled = !settings.blockingEnabled
        refresh(animate = true)

        val main = requireActivity() as MainActivity
        main.refreshProtection(animate = true)
        main.showToast(if (settings.blockingEnabled) "Call blocking turned on" else "Call blocking turned off")
    }

    private fun replay(v: View) {
        v.animate().cancel()
        v.alpha = 0f
        v.translationY = 6 * resources.displayMetrics.density
        v.animate().alpha(1f).translationY(0f).setDuration(500).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun refresh(animate: Boolean) {
        val binding = _b ?: return
        val ctx = requireContext()
        val settings = AppSettings(ctx)
        val complete = Setup.isComplete(ctx)

        val on: Boolean
        val color: Int
        val power: String
        val status: String
        val desc: String
        val hint: String
        when {
            !complete -> {
                on = false; color = ctx.getColor(R.color.warning); power = "SETUP"
                status = "Setup Required"
                desc = "Allow contacts access and choose this app as your call screening app."
                hint = "Tap the button to finish setup"
            }
            !settings.blockingEnabled -> {
                on = false; color = ctx.getColor(R.color.danger_text); power = "OFF"
                status = "Protection Off"
                desc = "Blocking is paused. Unknown numbers can call you right now."
                hint = "Tap the button to turn on"
            }
            else -> {
                on = true; color = ctx.getColor(R.color.accent); power = "ON"
                status = "Protection Active"
                desc = "Unknown numbers are rejected automatically. Only your saved contacts can reach you."
                hint = "Tap the button to turn off"
            }
        }

        val changed = binding.textState.text.toString() != status
        binding.powerButton.setState(on, power, animate)
        binding.powerButton.contentDescription = "Call blocking $power"

        binding.statusPill.background = GlassUi.tinted(ctx, color, 30f, fill = 0.04f, line = 0.17f)
        binding.statusDot.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
        }
        binding.textState.setTextColor(color)
        binding.textState.text = status
        binding.textStateDesc.text = desc
        binding.textHint.text = hint
        if (animate && changed) {
            replay(binding.statusPill)
            replay(binding.textStateDesc)
            replay(binding.textHint)
        }

        val (total, blocked) = CallLogStore(ctx).todayCounts()
        binding.textTotal.text = total.toString()
        binding.textBlockedToday.text = blocked.toString()
        binding.textAllowedToday.text = (total - blocked).coerceAtLeast(0).toString()

        val granted = ctx.getColor(R.color.accent)
        val missing = ctx.getColor(R.color.warning)
        val hasContacts = Setup.hasContacts(ctx)
        val hasRole = Setup.hasRole(ctx)
        binding.tagContacts.text = if (hasContacts) "Granted" else "Not set"
        GlassUi.styleTag(binding.tagContacts, if (hasContacts) granted else missing)
        binding.tagRole.text = if (hasRole) "Selected" else "Not set"
        GlassUi.styleTag(binding.tagRole, if (hasRole) granted else missing)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _b = null
    }

    private companion object {
        var entranceShown = false
    }
}
