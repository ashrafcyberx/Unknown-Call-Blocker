package com.ashrafcyberx.unknowncallblocker

import android.telecom.Call
import android.telecom.CallScreeningService
import android.telecom.TelecomManager
import android.util.Log

class UnknownCallScreeningService : CallScreeningService() {

    override fun onScreenCall(callDetails: Call.Details) {
        var reject = false
        try {
            val handle = callDetails.handle
            // Only plain phone numbers are screened; SIP or other schemes are always allowed.
            val screenable = handle == null || handle.scheme == "tel"
            if (screenable) {
                val number = handle?.schemeSpecificPart
                val incoming = callDetails.callDirection == Call.Details.DIRECTION_INCOMING
                val info = CallInfo(
                    isIncoming = incoming,
                    number = number,
                    isHiddenOrRestricted =
                        callDetails.handlePresentation == TelecomManager.PRESENTATION_RESTRICTED
                )
                val settings = AppSettings(applicationContext)
                val hasPermission = Setup.hasContacts(this)
                val config = BlockerConfig(
                    blockingEnabled = settings.blockingEnabled,
                    hasContactsPermission = hasPermission,
                    hiddenCallerPolicy = settings.hiddenCallerPolicy,
                    blockedNumbers = BlockedNumbersStore(applicationContext).list()
                )
                val repo = ContactsRepository(applicationContext)
                val result = CallDecisionEngine.decide(info, config) { repo.isSavedContact(it) }
                Log.d(TAG, "Decision=${result.decision} reason=${result.reason}")
                reject = result.decision == Decision.REJECT
                if (incoming) recordCall(number, reject, hasPermission, repo)
            }
        } catch (t: Throwable) {
            Log.e(TAG, "Screening failed; allowing call", t)
            reject = false
        }

        // BUSY and SWITCH_OFF both reject the call on the phone. What the caller hears is decided by the
        // carrier: BUSY = normal busy tone; SWITCH_OFF = rejected call is forwarded (user-set **67* code)
        // to a switched-off number so the network plays its "not reachable" message.
        val response = if (reject) {
            CallResponse.Builder()
                .setDisallowCall(true)
                .setRejectCall(true)
                .setSkipCallLog(false)        // keep the missed-call entry in the system call log
                .setSkipNotification(false)   // keep the missed-call notification
                .build()
        } else {
            CallResponse.Builder().build()
        }
        respondToCall(callDetails, response)
    }

    /** Stores a local log entry. Never affects the allow/reject decision. */
    private fun recordCall(number: String?, blocked: Boolean, hasPermission: Boolean, repo: ContactsRepository) {
        try {
            val clean = number?.takeIf { PhoneNumberMatcher.digitsOnly(it).isNotEmpty() } ?: ""
            var name: String? = null
            if (!blocked && clean.isNotEmpty() && hasPermission) {
                name = try {
                    repo.displayName(clean)
                } catch (e: Throwable) {
                    null
                }
            }
            CallLogStore(applicationContext).add(LogEntry(clean, name, blocked, System.currentTimeMillis()))
        } catch (t: Throwable) {
            Log.w(TAG, "Could not write call log entry", t)
        }
    }

    private companion object {
        const val TAG = "UnknownCallBlocker"
    }
}
